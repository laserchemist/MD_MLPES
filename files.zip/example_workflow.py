#!/usr/bin/env python3
"""
Example: Complete ML-PES Refinement Workflow
=============================================
Demonstrates the complete refinement workflow with all components.

This example shows:
1. Loading an ML-PES model
2. Normal mode analysis
3. GP uncertainty quantification
4. Active learning refinement
5. Progress tracking

Author: Jonathan
Date: 2026-01-20
"""

import numpy as np
from pathlib import Path
import sys


def example_workflow():
    """
    Complete example workflow for ML-PES refinement.
    
    This is a simplified example using synthetic data.
    Replace with your actual ML-PES model and training data.
    """
    
    print("=" * 80)
    print("  EXAMPLE: ML-PES Refinement Workflow")
    print("=" * 80)
    
    # ===================================================================
    # STEP 1: Setup (using synthetic data for demonstration)
    # ===================================================================
    
    print("\n" + "=" * 80)
    print("STEP 1: Setup Test System")
    print("=" * 80)
    
    # Create a simple test molecule (H2)
    symbols = ['H', 'H']
    reference_coords = np.array([
        [0.0, 0.0, 0.0],
        [1.4, 0.0, 0.0]  # ~0.74 Å bond length
    ])
    
    print(f"\nMolecule: {' '.join(symbols)}")
    print(f"Atoms: {len(symbols)}")
    print(f"Reference geometry:\n{reference_coords}")
    
    # Create mock training data
    print("\nGenerating synthetic training data...")
    
    # Simple harmonic potential around equilibrium
    n_train = 50
    r_min, r_max = 1.0, 2.0
    r_eq = 1.4
    k = 1.0  # Force constant
    
    training_coords = []
    training_energies = []
    
    for r in np.linspace(r_min, r_max, n_train):
        coords = np.array([
            [0.0, 0.0, 0.0],
            [r, 0.0, 0.0]
        ])
        energy = 0.5 * k * (r - r_eq)**2
        
        training_coords.append(coords)
        training_energies.append(energy)
    
    training_coords = np.array(training_coords)
    training_energies = np.array(training_energies)
    
    print(f"✓ Generated {len(training_coords)} training points")
    print(f"  Energy range: {training_energies.min():.4f} - {training_energies.max():.4f} Ha")
    
    # ===================================================================
    # STEP 2: Create Mock ML-PES Model
    # ===================================================================
    
    print("\n" + "=" * 80)
    print("STEP 2: Create ML-PES Model")
    print("=" * 80)
    
    class MockMLPES:
        """Simple mock ML-PES for demonstration."""
        
        def __init__(self):
            self.symbols = symbols
            self.k = k
            self.r_eq = r_eq
        
        def predict_energy(self, coords):
            """Predict energy (harmonic potential)."""
            r = np.linalg.norm(coords[1] - coords[0])
            return 0.5 * self.k * (r - self.r_eq)**2
        
        def predict_with_forces(self, coords):
            """Predict energy and forces."""
            r_vec = coords[1] - coords[0]
            r = np.linalg.norm(r_vec)
            
            energy = 0.5 * self.k * (r - self.r_eq)**2
            
            # Forces (analytical for harmonic)
            f_mag = -self.k * (r - self.r_eq)
            f_vec = f_mag * r_vec / r
            
            forces = np.array([
                -f_vec,  # Force on atom 0
                f_vec    # Force on atom 1
            ])
            
            return energy, forces
    
    ml_pes = MockMLPES()
    
    print(f"\n✓ ML-PES model created")
    print(f"  Model type: Harmonic oscillator (for demonstration)")
    print(f"  Equilibrium distance: {ml_pes.r_eq:.2f} Å")
    
    # Test prediction
    test_energy, test_forces = ml_pes.predict_with_forces(reference_coords)
    print(f"\n  Test prediction at reference:")
    print(f"    Energy: {test_energy:.6f} Ha")
    print(f"    Force magnitude: {np.linalg.norm(test_forces):.6f} Ha/Å")
    
    # ===================================================================
    # STEP 3: Normal Mode Analysis
    # ===================================================================
    
    print("\n" + "=" * 80)
    print("STEP 3: Normal Mode Analysis")
    print("=" * 80)
    
    from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler
    
    # Create analyzer
    analyzer = NormalModeAnalyzer(symbols, reference_coords)
    
    # Compute Hessian
    print("\nComputing Hessian numerically...")
    hessian = analyzer.compute_hessian_numerical(ml_pes, delta=0.01)
    
    print(f"✓ Hessian computed: {hessian.shape}")
    
    # Analyze normal modes
    print("\nAnalyzing normal modes...")
    nm_data = analyzer.analyze_normal_modes(hessian)
    
    print(f"\n✓ Normal modes computed:")
    print(f"  Total modes: {len(nm_data.frequencies)}")
    print(f"  Frequencies (cm⁻¹):")
    for i, freq in enumerate(nm_data.frequencies):
        if abs(freq) > 10:  # Skip near-zero frequencies
            print(f"    Mode {i+1}: {freq:.1f} cm⁻¹")
    
    # Create sampler
    sampler = NormalModeSampler(nm_data)
    
    # Select important modes
    mode_indices = sampler.select_important_modes(
        min_frequency=50.0,
        n_modes=2
    )
    
    # Generate samples
    if len(mode_indices) > 0:
        print(f"\nGenerating samples along {len(mode_indices)} mode(s)...")
        
        coords_samples, metadata = sampler.generate_samples_multiple_modes(
            mode_indices=mode_indices[:1],  # Just first mode for demo
            n_points_per_mode=11,
            max_displacement=0.2,
            strategy='grid'
        )
        
        print(f"✓ Generated {len(coords_samples)} samples")
    
    # ===================================================================
    # STEP 4: Gaussian Process Uncertainty
    # ===================================================================
    
    print("\n" + "=" * 80)
    print("STEP 4: Gaussian Process Uncertainty Quantification")
    print("=" * 80)
    
    from gp_uncertainty import GaussianProcessPES
    
    # Create GP model
    gp = GaussianProcessPES(kernel='rbf', alpha=1e-5)
    
    # Simple descriptor (just bond length for H2)
    def simple_descriptor(symbols, coords):
        r = np.linalg.norm(coords[1] - coords[0])
        return np.array([r, r**2, r**3])  # Polynomial features
    
    # Train GP
    print("\nTraining GP model...")
    gp.fit(
        coordinates=training_coords,
        energies=training_energies,
        descriptor_func=simple_descriptor,
        symbols=symbols
    )
    
    # Test prediction
    print("\nTesting GP predictions...")
    
    test_coords = np.array([
        [0.0, 0.0, 0.0],
        [1.6, 0.0, 0.0]  # Slightly stretched
    ])
    
    pred = gp.predict_with_uncertainty(test_coords)
    
    print(f"\n✓ GP prediction:")
    print(f"  Energy: {pred.mean_energy:.6f} ± {pred.std_energy:.6f} Ha")
    print(f"  Uncertainty: {pred.energy_uncertainty_kcal():.2f} kcal/mol")
    
    # Identify high-uncertainty regions
    if len(coords_samples) > 0:
        print("\nIdentifying high-uncertainty points...")
        
        high_unc_coords, indices, uncertainties = gp.identify_high_uncertainty_points(
            coords_samples,
            threshold_kcal=1.0,
            top_n=5
        )
        
        print(f"\n✓ Found {len(high_unc_coords)} high-uncertainty points")
        if len(high_unc_coords) > 0:
            print(f"  Uncertainty range: {uncertainties[indices].min():.2f} - {uncertainties[indices].max():.2f} kcal/mol")
    
    # ===================================================================
    # STEP 5: Active Learning Refinement
    # ===================================================================
    
    print("\n" + "=" * 80)
    print("STEP 5: Active Learning Refinement")
    print("=" * 80)
    
    from active_learning import RefinementConfig
    
    # Create config
    config = RefinementConfig(
        use_normal_modes=True,
        use_uncertainty=True,
        use_error_based=False,
        n_normal_modes=2,
        batch_size=10,
        max_iterations=1,  # Just 1 for demo
        convergence_rmse_kcal=0.5,
        method='B3LYP',
        basis='6-31G*',
        output_dir=Path('example_refinement_output')
    )
    
    print(f"\n✓ Refinement configuration:")
    print(f"  Normal modes: {config.use_normal_modes}")
    print(f"  GP uncertainty: {config.use_uncertainty}")
    print(f"  Batch size: {config.batch_size}")
    print(f"  Max iterations: {config.max_iterations}")
    
    print(f"\n💡 In a real workflow, the coordinator would:")
    print(f"   1. Generate candidate points (normal modes + MD)")
    print(f"   2. Select by uncertainty")
    print(f"   3. Compute PSI4 energies/forces")
    print(f"   4. Retrain ML-PES model")
    print(f"   5. Iterate until convergence")
    
    # ===================================================================
    # STEP 6: Summary
    # ===================================================================
    
    print("\n" + "=" * 80)
    print("WORKFLOW COMPLETE")
    print("=" * 80)
    
    print(f"\n✅ This example demonstrated:")
    print(f"   • Normal mode analysis and sampling")
    print(f"   • GP uncertainty quantification")
    print(f"   • Active learning configuration")
    print(f"   • Integration of all components")
    
    print(f"\n💡 To run with real data:")
    print(f"\n   python refine_mlpes.py \\")
    print(f"       --model your_model.pkl \\")
    print(f"       --training-data your_data.npz \\")
    print(f"       --strategy combined \\")
    print(f"       --batch-size 100 \\")
    print(f"       --max-iterations 5")
    
    print(f"\n📊 Monitor with dashboard:")
    print(f"   python refinement_dashboard.py refinement_output/")
    
    print(f"\n🧪 Run tests:")
    print(f"   python test_refinement_modules.py")
    
    print("")


if __name__ == '__main__':
    try:
        example_workflow()
    except ImportError as e:
        print(f"\n❌ Import error: {e}")
        print(f"\nMake sure all modules are in the current directory:")
        print(f"  • normal_mode_sampler.py")
        print(f"  • gp_uncertainty.py")
        print(f"  • active_learning.py")
        print(f"  • refinement_dashboard.py")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
