#!/usr/bin/env python3
"""
Complete ML-PES Refinement Workflow
====================================
Comprehensive workflow combining:
- Normal mode sampling
- Gaussian Process uncertainty
- Active learning refinement

Author: Jonathan
Date: 2026-01-20
Version: 1.0
"""

import sys
import numpy as np
from pathlib import Path
from datetime import datetime
import argparse
import pickle
import json


print("=" * 80)
print("  COMPREHENSIVE ML-PES REFINEMENT WORKFLOW")
print("=" * 80)


# Check imports
try:
    from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler
    from gp_uncertainty import GaussianProcessPES
    from active_learning import ActiveLearningCoordinator, RefinementConfig
    print("✅ Refinement modules imported")
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("   Make sure all modules are in the current directory")
    sys.exit(1)

try:
    import psi4
    print(f"✅ PSI4 {psi4.__version__}")
except ImportError:
    print("❌ PSI4 required for refinement")
    sys.exit(1)


def load_ml_pes_model(model_path: Path):
    """Load ML-PES model with robust error handling."""
    print(f"\n{'='*70}")
    print(f"Loading ML-PES Model")
    print(f"{'='*70}")
    print(f"  Path: {model_path}")
    
    with open(model_path, 'rb') as f:
        model_data = pickle.load(f)
    
    # Create wrapper class
    class MLPESWrapper:
        def __init__(self, model_data):
            self.model = model_data['model']
            self.scaler_X = model_data['scaler_X']
            self.scaler_y = model_data['scaler_y']
            self.symbols = model_data['symbols']
            self.metadata = model_data.get('metadata', {})
            
            # Extract theory
            theory = self.metadata.get('theory', {})
            self.method = theory.get('method', 'B3LYP')
            self.basis = theory.get('basis', '6-31G*')
        
        def compute_coulomb_matrix(self, coords):
            """Compute Coulomb matrix descriptor."""
            atomic_numbers = {'H': 1, 'C': 6, 'N': 7, 'O': 8, 'F': 9, 'S': 16}
            Z = np.array([atomic_numbers.get(s, 0) for s in self.symbols])
            n_atoms = len(self.symbols)
            cm = np.zeros((n_atoms, n_atoms))
            
            for i in range(n_atoms):
                for j in range(n_atoms):
                    if i == j:
                        cm[i, j] = 0.5 * Z[i]**2.4
                    else:
                        r_ij = np.linalg.norm(coords[i] - coords[j])
                        cm[i, j] = Z[i] * Z[j] / (r_ij + 1e-10)
            
            return cm[np.triu_indices(n_atoms)]
        
        def predict_energy(self, coords):
            """Predict energy."""
            desc = self.compute_coulomb_matrix(coords)
            desc_scaled = self.scaler_X.transform(desc.reshape(1, -1))
            e_scaled = self.model.predict(desc_scaled)[0]
            energy = self.scaler_y.inverse_transform([[e_scaled]])[0, 0]
            return energy
        
        def predict_with_forces(self, coords, delta=0.001):
            """Predict energy and forces."""
            energy = self.predict_energy(coords)
            
            # Finite difference forces
            n_atoms = len(self.symbols)
            forces = np.zeros((n_atoms, 3))
            
            for i in range(n_atoms):
                for j in range(3):
                    coords_plus = coords.copy()
                    coords_minus = coords.copy()
                    
                    coords_plus[i, j] += delta
                    coords_minus[i, j] -= delta
                    
                    e_plus = self.predict_energy(coords_plus)
                    e_minus = self.predict_energy(coords_minus)
                    
                    forces[i, j] = -(e_plus - e_minus) / (2 * delta)
            
            return energy, forces
    
    wrapper = MLPESWrapper(model_data)
    
    print(f"  ✅ Model loaded")
    print(f"     Theory: {wrapper.method}/{wrapper.basis}")
    print(f"     Molecule: {' '.join(wrapper.symbols)}")
    
    return wrapper


def load_training_data(data_path: Path):
    """Load training data."""
    print(f"\n{'='*70}")
    print(f"Loading Training Data")
    print(f"{'='*70}")
    print(f"  Path: {data_path}")
    
    data = np.load(data_path, allow_pickle=True)
    
    symbols = list(data['symbols'])
    coordinates = data['coordinates']
    energies = data['energies']
    forces = data.get('forces', None)
    
    print(f"  ✅ Data loaded")
    print(f"     Frames: {len(coordinates)}")
    print(f"     Atoms: {len(symbols)} ({' '.join(symbols)})")
    
    return {
        'symbols': symbols,
        'coordinates': coordinates,
        'energies': energies,
        'forces': forces
    }


def retrain_model(
    original_coords: np.ndarray,
    original_energies: np.ndarray,
    new_coords: np.ndarray,
    new_energies: np.ndarray,
    symbols: List[str],
    output_path: Path
) -> float:
    """
    Retrain ML-PES with augmented data.
    
    Returns:
        Test RMSE (kcal/mol)
    """
    from sklearn.kernel_ridge import KernelRidge
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error, r2_score
    
    print(f"\n{'='*70}")
    print(f"Retraining ML-PES Model")
    print(f"{'='*70}")
    
    # Combine data
    all_coords = np.vstack([original_coords, new_coords])
    all_energies = np.concatenate([original_energies, new_energies])
    
    print(f"  Total training points: {len(all_coords)}")
    print(f"    Original: {len(original_coords)}")
    print(f"    New: {len(new_coords)}")
    
    # Compute descriptors
    def compute_cm(coords):
        atomic_numbers = {'H': 1, 'C': 6, 'N': 7, 'O': 8, 'F': 9, 'S': 16}
        Z = np.array([atomic_numbers.get(s, 0) for s in symbols])
        n_atoms = len(symbols)
        cm = np.zeros((n_atoms, n_atoms))
        
        for i in range(n_atoms):
            for j in range(n_atoms):
                if i == j:
                    cm[i, j] = 0.5 * Z[i]**2.4
                else:
                    r_ij = np.linalg.norm(coords[i] - coords[j])
                    cm[i, j] = Z[i] * Z[j] / (r_ij + 1e-10)
        
        return cm[np.triu_indices(n_atoms)]
    
    print(f"\n  Computing descriptors...")
    X = np.array([compute_cm(coords) for coords in all_coords])
    y = all_energies
    
    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Scale
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    X_train_scaled = scaler_X.fit_transform(X_train)
    X_test_scaled = scaler_X.transform(X_test)
    y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).ravel()
    y_test_scaled = scaler_y.transform(y_test.reshape(-1, 1)).ravel()
    
    # Train with hyperparameter search
    print(f"\n  Training with hyperparameter search...")
    
    from itertools import product
    
    gammas = [0.0001, 0.001, 0.01]
    alphas = [0.001, 0.01, 0.1]
    
    best_rmse = float('inf')
    best_params = None
    best_model = None
    
    for gamma, alpha in product(gammas, alphas):
        model = KernelRidge(kernel='rbf', gamma=gamma, alpha=alpha)
        model.fit(X_train_scaled, y_train_scaled)
        
        y_pred_scaled = model.predict(X_test_scaled)
        y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
        
        rmse = np.sqrt(mean_squared_error(y_test, y_pred)) * 627.509
        
        if rmse < best_rmse:
            best_rmse = rmse
            best_params = (gamma, alpha)
            best_model = model
    
    print(f"\n  ✅ Training complete")
    print(f"     Best params: gamma={best_params[0]}, alpha={best_params[1]}")
    print(f"     Test RMSE: {best_rmse:.4f} kcal/mol")
    
    # R² score
    y_pred_scaled = best_model.predict(X_test_scaled)
    y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
    r2 = r2_score(y_test, y_pred)
    print(f"     R² score: {r2:.4f}")
    
    # Save model
    model_data = {
        'model': best_model,
        'scaler_X': scaler_X,
        'scaler_y': scaler_y,
        'symbols': symbols,
        'metadata': {
            'training_points': len(all_coords),
            'test_rmse_kcal': float(best_rmse),
            'r2_score': float(r2),
            'hyperparameters': {
                'gamma': float(best_params[0]),
                'alpha': float(best_params[1])
            }
        }
    }
    
    with open(output_path, 'wb') as f:
        pickle.dump(model_data, f)
    
    print(f"  ✓ Saved: {output_path}")
    
    return best_rmse


def main():
    """Main refinement workflow."""
    
    parser = argparse.ArgumentParser(description='ML-PES Refinement Workflow')
    
    # Required arguments
    parser.add_argument('--model', required=True, help='Path to ML-PES model (.pkl)')
    parser.add_argument('--training-data', required=True, help='Path to training data (.npz)')
    
    # Refinement strategy
    parser.add_argument('--strategy', choices=['normal_modes', 'uncertainty', 'combined'],
                       default='combined', help='Refinement strategy')
    
    # Configuration
    parser.add_argument('--batch-size', type=int, default=100,
                       help='Points to add per iteration')
    parser.add_argument('--max-iterations', type=int, default=3,
                       help='Maximum refinement iterations')
    parser.add_argument('--target-rmse', type=float, default=1.0,
                       help='Target RMSE (kcal/mol) for convergence')
    
    # Normal mode options
    parser.add_argument('--n-modes', type=int, default=5,
                       help='Number of normal modes to sample')
    parser.add_argument('--mode-displacement', type=float, default=0.2,
                       help='Maximum displacement along modes (Å)')
    
    # Uncertainty options
    parser.add_argument('--uncertainty-threshold', type=float, default=5.0,
                       help='Uncertainty threshold (kcal/mol)')
    
    # Output
    parser.add_argument('--output-dir', type=Path,
                       default=Path(f'refinement_{datetime.now().strftime("%Y%m%d_%H%M%S")}'),
                       help='Output directory')
    
    args = parser.parse_args()
    
    # Load model
    ml_pes = load_ml_pes_model(Path(args.model))
    
    # Load training data
    training_data = load_training_data(Path(args.training_data))
    
    # Get reference geometry (lowest energy)
    lowest_idx = np.argmin(training_data['energies'])
    reference_coords = training_data['coordinates'][lowest_idx].copy()
    
    print(f"\n  Reference geometry: frame {lowest_idx} (lowest energy)")
    
    # Create refinement config
    config = RefinementConfig(
        use_normal_modes=(args.strategy in ['normal_modes', 'combined']),
        use_uncertainty=(args.strategy in ['uncertainty', 'combined']),
        use_error_based=False,  # Not implemented in this version
        n_normal_modes=args.n_modes,
        normal_mode_displacement=args.mode_displacement,
        uncertainty_threshold_kcal=args.uncertainty_threshold,
        batch_size=args.batch_size,
        max_iterations=args.max_iterations,
        convergence_rmse_kcal=args.target_rmse,
        method=ml_pes.method,
        basis=ml_pes.basis,
        output_dir=args.output_dir
    )
    
    # Initialize coordinator
    coordinator = ActiveLearningCoordinator(
        config=config,
        ml_pes_model=ml_pes,
        reference_coords=reference_coords,
        symbols=training_data['symbols']
    )
    
    # Setup components
    if config.use_normal_modes:
        coordinator.setup_normal_mode_sampling()
    
    if config.use_uncertainty:
        coordinator.setup_uncertainty_model(
            training_data['coordinates'],
            training_data['energies']
        )
    
    # Refinement loop
    current_rmse = float('inf')
    
    for iteration in range(1, config.max_iterations + 1):
        
        # Run iteration
        result = coordinator.run_refinement_iteration(
            iteration=iteration,
            current_training_coords=training_data['coordinates'],
            current_training_energies=training_data['energies'],
            current_training_forces=training_data.get('forces', None)
        )
        
        # Retrain model
        print(f"\n{'='*70}")
        print(f"Retraining Model")
        print(f"{'='*70}")
        
        retrained_model_path = config.output_dir / f'model_iteration_{iteration}.pkl'
        
        new_rmse = retrain_model(
            original_coords=training_data['coordinates'],
            original_energies=training_data['energies'],
            new_coords=result.coordinates_added,
            new_energies=result.energies_added,
            symbols=training_data['symbols'],
            output_path=retrained_model_path
        )
        
        # Update result
        result.model_rmse_before = current_rmse
        result.model_rmse_after = new_rmse
        
        if current_rmse != float('inf'):
            result.improvement_pct = (current_rmse - new_rmse) / current_rmse * 100
        
        current_rmse = new_rmse
        
        # Store result
        coordinator.refinement_history.append(result)
        
        # Check convergence
        print(f"\n{'='*70}")
        print(f"Iteration {iteration} Summary")
        print(f"{'='*70}")
        print(f"  Points added: {result.n_points_added}")
        print(f"  Model RMSE: {new_rmse:.4f} kcal/mol")
        
        if current_rmse != float('inf') and result.model_rmse_before != float('inf'):
            print(f"  Improvement: {result.improvement_pct:+.2f}%")
        
        if new_rmse < config.convergence_rmse_kcal:
            print(f"\n✅ Converged! RMSE below target ({config.convergence_rmse_kcal} kcal/mol)")
            break
    
    # Save history
    coordinator.save_refinement_history()
    
    # Final summary
    print(f"\n{'='*70}")
    print(f"REFINEMENT COMPLETE")
    print(f"{'='*70}")
    print(f"\n📂 Output directory: {config.output_dir}")
    print(f"\n📊 Summary:")
    print(f"  Iterations: {len(coordinator.refinement_history)}")
    print(f"  Total points added: {sum(r.n_points_added for r in coordinator.refinement_history)}")
    print(f"  Final RMSE: {current_rmse:.4f} kcal/mol")
    
    if len(coordinator.refinement_history) > 0:
        first_rmse = coordinator.refinement_history[0].model_rmse_before
        if first_rmse != float('inf'):
            total_improvement = (first_rmse - current_rmse) / first_rmse * 100
            print(f"  Total improvement: {total_improvement:+.2f}%")
    
    print(f"\n💡 Next steps:")
    print(f"  1. Test refined model:")
    print(f"     python two_phase_workflow.py \\")
    print(f"         --model {config.output_dir}/model_iteration_{len(coordinator.refinement_history)}.pkl \\")
    print(f"         --training-data {args.training_data}")
    print(f"")
    print(f"  2. Compute IR spectrum:")
    print(f"     python compute_ir_spectrum.py --model [refined_model]")


if __name__ == '__main__':
    try:
        from typing import List
        main()
    except KeyboardInterrupt:
        print("\n\nExiting...")
        sys.exit(0)
