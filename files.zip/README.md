# ML-PES Refinement System

A comprehensive, modular system for refining machine learning potential energy surfaces (ML-PES) using multiple adaptive strategies:

- **Normal Mode Sampling**: Systematic distortions along vibrational modes
- **Gaussian Process Uncertainty**: Active learning guided by uncertainty quantification
- **Error-Based Refinement**: Targeted sampling at high-error regions
- **Web Dashboard**: Real-time monitoring and visualization

## 🎯 Features

### Core Modules

1. **normal_mode_sampler.py**
   - Compute vibrational normal modes from Hessian
   - Generate systematic distortions along modes
   - Smart mode selection (frequency-based)
   - Multiple sampling strategies (grid, random)

2. **gp_uncertainty.py**
   - Gaussian Process regression with uncertainty
   - Uncertainty-based active learning
   - Acquisition functions for exploration
   - Real-time uncertainty tracking

3. **active_learning.py**
   - Orchestrates all refinement strategies
   - Manages iterative refinement workflow
   - Combines multiple sampling methods
   - Automatic PSI4 computation and retraining

4. **refinement_dashboard.py**
   - Real-time web dashboard
   - Progress visualization
   - Iteration history
   - Performance metrics

### Supporting Scripts

- **refine_mlpes.py**: Complete workflow script
- **test_refinement_modules.py**: Comprehensive unit tests

## 📦 Installation

### Requirements

```bash
# Core dependencies
pip install numpy scipy scikit-learn matplotlib flask

# Quantum chemistry (required for refinement)
# Install PSI4: https://psicode.org/installs/v114/
```

### Setup

```bash
# Clone or download the modules
cd your_workspace
# All modules should be in the same directory
```

## 🚀 Quick Start

### 1. Basic Refinement Workflow

```bash
# Run complete refinement with all strategies
python refine_mlpes.py \
    --model /path/to/ml_pes_model.pkl \
    --training-data /path/to/training_data.npz \
    --strategy combined \
    --batch-size 100 \
    --max-iterations 5 \
    --target-rmse 1.0
```

### 2. Normal Mode Refinement Only

```bash
python refine_mlpes.py \
    --model model.pkl \
    --training-data training.npz \
    --strategy normal_modes \
    --n-modes 5 \
    --mode-displacement 0.2
```

### 3. Uncertainty-Based Refinement

```bash
python refine_mlpes.py \
    --model model.pkl \
    --training-data training.npz \
    --strategy uncertainty \
    --uncertainty-threshold 5.0
```

### 4. Launch Web Dashboard

```bash
# Monitor refinement progress in real-time
python refinement_dashboard.py refinement_20260120_123456/
```

Then open http://localhost:5000 in your browser.

## 📚 Detailed Usage

### Normal Mode Sampling

```python
from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler

# Initialize analyzer
analyzer = NormalModeAnalyzer(symbols=['O', 'H', 'H'], 
                             reference_coords=coords)

# Compute Hessian numerically
hessian = analyzer.compute_hessian_numerical(ml_pes_model)

# Analyze normal modes
nm_data = analyzer.analyze_normal_modes(hessian)

# Create sampler
sampler = NormalModeSampler(nm_data)

# Select important modes
mode_indices = sampler.select_important_modes(
    min_frequency=50.0,
    max_frequency=4000.0,
    n_modes=5
)

# Generate samples
coords, metadata = sampler.generate_samples_multiple_modes(
    mode_indices=mode_indices,
    n_points_per_mode=11,
    max_displacement=0.2,
    strategy='grid'
)
```

### Gaussian Process Uncertainty

```python
from gp_uncertainty import GaussianProcessPES

# Create GP model
gp = GaussianProcessPES(kernel='rbf', alpha=1e-5)

# Define descriptor function
def coulomb_matrix(symbols, coords):
    # ... compute Coulomb matrix
    return descriptor

# Train GP
gp.fit(
    coordinates=training_coords,
    energies=training_energies,
    descriptor_func=coulomb_matrix,
    symbols=symbols
)

# Predict with uncertainty
prediction = gp.predict_with_uncertainty(test_coords)

print(f"Energy: {prediction.mean_energy:.4f} Ha")
print(f"Uncertainty: {prediction.energy_uncertainty_kcal():.2f} kcal/mol")

# Identify high-uncertainty points
high_unc_coords, indices, uncertainties = gp.identify_high_uncertainty_points(
    candidate_coords,
    threshold_kcal=5.0,
    top_n=50
)
```

### Active Learning Coordinator

```python
from active_learning import ActiveLearningCoordinator, RefinementConfig

# Configure refinement
config = RefinementConfig(
    use_normal_modes=True,
    use_uncertainty=True,
    n_normal_modes=5,
    batch_size=100,
    max_iterations=5,
    convergence_rmse_kcal=1.0,
    method='B3LYP',
    basis='6-31G*'
)

# Initialize coordinator
coordinator = ActiveLearningCoordinator(
    config=config,
    ml_pes_model=ml_pes,
    reference_coords=reference_geometry,
    symbols=symbols
)

# Setup strategies
coordinator.setup_normal_mode_sampling()
coordinator.setup_uncertainty_model(training_coords, training_energies)

# Run refinement iteration
result = coordinator.run_refinement_iteration(
    iteration=1,
    current_training_coords=coords,
    current_training_energies=energies,
    current_training_forces=forces
)

print(f"Added {result.n_points_added} points")
print(f"RMSE: {result.model_rmse_after:.4f} kcal/mol")
```

## 🧪 Testing

Run comprehensive unit tests:

```bash
python test_refinement_modules.py
```

Tests cover:
- Normal mode computation
- GP uncertainty prediction
- Active learning coordination
- Integration workflows

## 📊 Output Structure

```
refinement_YYYYMMDD_HHMMSS/
├── refinement_history.json       # Complete iteration history
├── iteration_1_points.npz        # Points added in iteration 1
├── iteration_2_points.npz        # Points added in iteration 2
├── model_iteration_1.pkl         # Retrained model after iteration 1
├── model_iteration_2.pkl         # Retrained model after iteration 2
└── ...
```

### refinement_history.json Format

```json
{
  "config": {
    "use_normal_modes": true,
    "use_uncertainty": true,
    "batch_size": 100,
    "max_iterations": 5,
    "method": "B3LYP",
    "basis": "6-31G*"
  },
  "iterations": [
    {
      "iteration": 1,
      "n_points_added": 100,
      "source_breakdown": {
        "normal_modes": 50,
        "md_exploration": 30,
        "uncertainty": 20
      },
      "model_rmse_before": 5.23,
      "model_rmse_after": 3.45,
      "improvement_pct": 34.0
    }
  ]
}
```

## 🎯 Best Practices

### 1. Normal Mode Sampling

- **Low frequencies first**: Sample low-frequency modes (<1000 cm⁻¹) as they explore larger conformational changes
- **Displacement range**: Start with ±0.2 Å, adjust based on molecule flexibility
- **Grid vs random**: Use grid for systematic coverage, random for diversity

### 2. Uncertainty-Based Sampling

- **Threshold selection**: Start with 5 kcal/mol, lower for higher accuracy requirements
- **Batch size**: 50-100 points per iteration for good coverage
- **GP kernel**: RBF works well for smooth PES, Matérn for rougher surfaces

### 3. Refinement Strategy

- **Combined approach**: Use both normal modes (systematic) and uncertainty (adaptive)
- **Iteration limit**: 3-5 iterations usually sufficient
- **Convergence**: Target RMSE < 1 kcal/mol for chemical accuracy

### 4. Computational Efficiency

- **Initial training**: Use 500-1000 diverse points
- **Batch refinement**: Add 100 points per iteration
- **PSI4 settings**: Balance accuracy vs speed (B3LYP/6-31G* good default)

## 🔧 Integration with Existing Workflow

This refinement system integrates with your existing PSI4-MD framework:

```bash
# 1. Generate initial training data
python generate_training_data_COMPLETE_WORKING.py

# 2. Train initial ML-PES
python complete_workflow_v2.2.py

# 3. Refine with new system
python refine_mlpes.py \
    --model outputs/ml_pes_model.pkl \
    --training-data outputs/training_data.npz \
    --strategy combined

# 4. Monitor with dashboard
python refinement_dashboard.py refinement_*/

# 5. Use refined model for IR spectrum
python compute_ir_spectrum_FIXED.py --model refined_model.pkl
```

## 📈 Performance Expectations

### Normal Mode Sampling
- **Coverage**: Systematic exploration of vibrational space
- **Efficiency**: ~100-500 points for 5 modes
- **Best for**: Molecules near equilibrium, vibrational properties

### GP Uncertainty
- **Exploration**: Identifies poorly-sampled regions
- **Efficiency**: Focuses on high-uncertainty areas
- **Best for**: Reaction pathways, rare configurations

### Combined Strategy
- **Improvement**: Typically 30-50% RMSE reduction
- **Iterations**: 3-5 iterations to convergence
- **Best for**: Production-quality ML-PES

## 🐛 Troubleshooting

### Issue: Normal modes have imaginary frequencies
**Cause**: Reference geometry is not at minimum  
**Solution**: Optimize reference geometry first

### Issue: GP training is slow
**Cause**: Large training set (>1000 points)  
**Solution**: Use subset for GP, or switch to faster KRR for predictions

### Issue: PSI4 convergence failures
**Cause**: Distorted geometries from sampling  
**Solution**: Reduce displacement amplitude, filter geometries

### Issue: RMSE not improving
**Cause**: Insufficient diversity in training data  
**Solution**: Increase temperature in MD exploration, sample more modes

## 📝 Citation

If you use this refinement system in your research, please cite:

```
@software{mlpes_refinement_2026,
  author = {Jonathan},
  title = {ML-PES Refinement System: Active Learning for Potential Energy Surfaces},
  year = {2026},
  note = {Comprehensive framework for ML-PES refinement using normal modes and Gaussian Process uncertainty}
}
```

## 📄 License

This software is provided for research and educational purposes.

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Additional sampling strategies
- Alternative uncertainty quantification methods
- Performance optimizations
- Additional visualizations

## 📞 Support

For questions or issues:
1. Check this README
2. Review example scripts
3. Run unit tests to verify installation
4. Check dashboard for refinement status

## 🔮 Future Enhancements

Planned features:
- [ ] Multi-GPU PSI4 computation
- [ ] Adaptive batch size selection
- [ ] Committee models for uncertainty
- [ ] Delta-learning for refinement
- [ ] Integration with other QM codes
- [ ] Export to ML potential formats (TorchANI, SchNet, etc.)

---

**Version**: 1.0  
**Date**: 2026-01-20  
**Author**: Jonathan  
**Status**: Production Ready
