#!/usr/bin/env python3
"""
ML-PES Refinement Dashboard
============================
Web dashboard for tracking and visualizing ML-PES refinement workflows.

Features:
- Real-time refinement progress
- Visualization of normal modes
- Uncertainty maps
- Model performance tracking
- Iteration history

Author: Jonathan
Date: 2026-01-20
Version: 1.0
"""

from flask import Flask, render_template_string, jsonify, request
import numpy as np
from pathlib import Path
import json
from datetime import datetime
import pickle
from typing import Dict, List, Optional


app = Flask(__name__)


# HTML Template
DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>ML-PES Refinement Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .header p {
            opacity: 0.9;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }
        
        .card-header {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #667eea;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .metric {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid #eee;
        }
        
        .metric:last-child {
            border-bottom: none;
        }
        
        .metric-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .metric-value {
            font-size: 1.3rem;
            font-weight: 600;
            color: #667eea;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-running {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-complete {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-pending {
            background: #e5e7eb;
            color: #374151;
        }
        
        .plot-container {
            width: 100%;
            height: 400px;
            margin: 1rem 0;
        }
        
        .full-width {
            grid-column: 1 / -1;
        }
        
        .iteration-card {
            background: #f9fafb;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 1rem;
            margin: 0.5rem 0;
        }
        
        .iteration-header {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #374151;
        }
        
        .iteration-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            font-size: 0.9rem;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.8rem;
            margin-bottom: 0.25rem;
        }
        
        .stat-value {
            font-weight: 600;
            color: #111827;
        }
        
        .refresh-button {
            background: #667eea;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: background 0.2s;
        }
        
        .refresh-button:hover {
            background: #5568d3;
        }
        
        .controls {
            text-align: right;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <h1>🔬 ML-PES Refinement Dashboard</h1>
            <p>Real-time monitoring of active learning and refinement workflows</p>
        </div>
    </div>
    
    <div class="container">
        <div class="controls">
            <button class="refresh-button" onclick="refreshData()">🔄 Refresh Data</button>
        </div>
        
        <!-- Overview Cards -->
        <div class="grid">
            <div class="card">
                <div class="card-header">📊 Current Status</div>
                <div class="metric">
                    <span class="metric-label">Status</span>
                    <span id="status-badge" class="status-badge status-pending">Loading...</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Current RMSE</span>
                    <span class="metric-value" id="current-rmse">--</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Target RMSE</span>
                    <span class="metric-value" id="target-rmse">--</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">🎯 Progress</div>
                <div class="metric">
                    <span class="metric-label">Iterations</span>
                    <span class="metric-value" id="iterations">--</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Points Added</span>
                    <span class="metric-value" id="points-added">--</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Improvement</span>
                    <span class="metric-value" id="improvement">--</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">⚙️ Configuration</div>
                <div class="metric">
                    <span class="metric-label">Strategy</span>
                    <span class="metric-value" id="strategy" style="font-size:1rem;">--</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Batch Size</span>
                    <span class="metric-value" id="batch-size">--</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Theory Level</span>
                    <span class="metric-value" id="theory" style="font-size:0.95rem;">--</span>
                </div>
            </div>
        </div>
        
        <!-- RMSE Progress Chart -->
        <div class="card full-width">
            <div class="card-header">📈 RMSE Progress Over Iterations</div>
            <div id="rmse-plot" class="plot-container"></div>
        </div>
        
        <!-- Points Added Chart -->
        <div class="card full-width">
            <div class="card-header">📍 Points Added Per Iteration</div>
            <div id="points-plot" class="plot-container"></div>
        </div>
        
        <!-- Iteration Details -->
        <div class="card full-width">
            <div class="card-header">📋 Iteration Details</div>
            <div id="iterations-list"></div>
        </div>
    </div>
    
    <script>
        async function fetchData() {
            try {
                const response = await fetch('/api/status');
                return await response.json();
            } catch (error) {
                console.error('Error fetching data:', error);
                return null;
            }
        }
        
        function updateStatus(data) {
            if (!data) return;
            
            // Status badge
            const statusBadge = document.getElementById('status-badge');
            if (data.status === 'running') {
                statusBadge.className = 'status-badge status-running';
                statusBadge.textContent = '🔄 Running';
            } else if (data.status === 'complete') {
                statusBadge.className = 'status-badge status-complete';
                statusBadge.textContent = '✅ Complete';
            } else {
                statusBadge.className = 'status-badge status-pending';
                statusBadge.textContent = '⏸️ Pending';
            }
            
            // Metrics
            document.getElementById('current-rmse').textContent = 
                data.current_rmse ? data.current_rmse.toFixed(4) + ' kcal/mol' : '--';
            document.getElementById('target-rmse').textContent = 
                data.target_rmse ? data.target_rmse.toFixed(2) + ' kcal/mol' : '--';
            document.getElementById('iterations').textContent = 
                data.iterations || '--';
            document.getElementById('points-added').textContent = 
                data.total_points || '--';
            
            const improvement = data.total_improvement;
            const improvementEl = document.getElementById('improvement');
            if (improvement !== null && improvement !== undefined) {
                improvementEl.textContent = (improvement > 0 ? '+' : '') + improvement.toFixed(1) + '%';
                improvementEl.style.color = improvement > 0 ? '#059669' : '#dc2626';
            } else {
                improvementEl.textContent = '--';
            }
            
            // Configuration
            document.getElementById('strategy').textContent = data.strategy || '--';
            document.getElementById('batch-size').textContent = data.batch_size || '--';
            document.getElementById('theory').textContent = data.theory || '--';
        }
        
        function plotRMSE(data) {
            if (!data || !data.iteration_history) return;
            
            const iterations = data.iteration_history.map(i => i.iteration);
            const rmse_values = data.iteration_history.map(i => i.rmse_after);
            
            const trace = {
                x: iterations,
                y: rmse_values,
                type: 'scatter',
                mode: 'lines+markers',
                marker: {
                    color: '#667eea',
                    size: 10
                },
                line: {
                    color: '#667eea',
                    width: 3
                },
                name: 'RMSE'
            };
            
            const layout = {
                xaxis: { title: 'Iteration', showgrid: true },
                yaxis: { title: 'RMSE (kcal/mol)', showgrid: true },
                margin: { t: 20, r: 20, b: 50, l: 60 },
                hovermode: 'closest'
            };
            
            Plotly.newPlot('rmse-plot', [trace], layout, {responsive: true});
        }
        
        function plotPoints(data) {
            if (!data || !data.iteration_history) return;
            
            const iterations = data.iteration_history.map(i => i.iteration);
            const points = data.iteration_history.map(i => i.points_added);
            
            const trace = {
                x: iterations,
                y: points,
                type: 'bar',
                marker: {
                    color: '#764ba2'
                },
                name: 'Points Added'
            };
            
            const layout = {
                xaxis: { title: 'Iteration', showgrid: false },
                yaxis: { title: 'Number of Points', showgrid: true },
                margin: { t: 20, r: 20, b: 50, l: 60 }
            };
            
            Plotly.newPlot('points-plot', [trace], layout, {responsive: true});
        }
        
        function renderIterations(data) {
            if (!data || !data.iteration_history) return;
            
            const container = document.getElementById('iterations-list');
            container.innerHTML = '';
            
            data.iteration_history.forEach(iter => {
                const card = document.createElement('div');
                card.className = 'iteration-card';
                
                const improvement = iter.improvement_pct !== undefined && iter.improvement_pct !== null
                    ? (iter.improvement_pct > 0 ? '+' : '') + iter.improvement_pct.toFixed(1) + '%'
                    : '--';
                
                card.innerHTML = `
                    <div class="iteration-header">Iteration ${iter.iteration}</div>
                    <div class="iteration-stats">
                        <div class="stat-item">
                            <div class="stat-label">Points Added</div>
                            <div class="stat-value">${iter.points_added}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">RMSE After</div>
                            <div class="stat-value">${iter.rmse_after.toFixed(4)} kcal/mol</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Improvement</div>
                            <div class="stat-value">${improvement}</div>
                        </div>
                    </div>
                `;
                
                container.appendChild(card);
            });
        }
        
        async function refreshData() {
            const data = await fetchData();
            if (data) {
                updateStatus(data);
                plotRMSE(data);
                plotPoints(data);
                renderIterations(data);
            }
        }
        
        // Initial load
        refreshData();
        
        // Auto-refresh every 30 seconds
        setInterval(refreshData, 30000);
    </script>
</body>
</html>
"""


class RefinementDashboard:
    """
    Dashboard for monitoring ML-PES refinement.
    
    Tracks:
    - Refinement iterations
    - Model performance
    - Training data growth
    - Uncertainty statistics
    """
    
    def __init__(self, refinement_dir: Path):
        """
        Initialize dashboard.
        
        Args:
            refinement_dir: Directory containing refinement outputs
        """
        self.refinement_dir = Path(refinement_dir)
        self.history_file = self.refinement_dir / 'refinement_history.json'
    
    def load_refinement_history(self) -> Optional[Dict]:
        """Load refinement history from file."""
        if not self.history_file.exists():
            return None
        
        with open(self.history_file, 'r') as f:
            return json.load(f)
    
    def get_status_data(self) -> Dict:
        """Get current status data for dashboard."""
        history = self.load_refinement_history()
        
        if history is None:
            return {
                'status': 'no_data',
                'message': 'No refinement history found'
            }
        
        # Extract data
        config = history.get('config', {})
        iterations = history.get('iterations', [])
        
        # Current status
        if len(iterations) == 0:
            status = 'pending'
            current_rmse = None
            total_improvement = None
        elif len(iterations) < config.get('max_iterations', 3):
            status = 'running'
            current_rmse = iterations[-1]['model_rmse_after']
            
            if len(iterations) > 1:
                first_rmse = iterations[0]['model_rmse_before']
                total_improvement = (first_rmse - current_rmse) / first_rmse * 100 if first_rmse else None
            else:
                total_improvement = None
        else:
            status = 'complete'
            current_rmse = iterations[-1]['model_rmse_after']
            
            if len(iterations) > 0:
                first_rmse = iterations[0]['model_rmse_before']
                total_improvement = (first_rmse - current_rmse) / first_rmse * 100 if first_rmse else None
            else:
                total_improvement = None
        
        # Strategy
        strategies = []
        if config.get('use_normal_modes'):
            strategies.append('Normal Modes')
        if config.get('use_uncertainty'):
            strategies.append('GP Uncertainty')
        if config.get('use_error_based'):
            strategies.append('Error-Based')
        
        strategy_str = ' + '.join(strategies) if strategies else 'Unknown'
        
        # Build response
        return {
            'status': status,
            'current_rmse': current_rmse,
            'target_rmse': config.get('convergence_rmse_kcal', 1.0),
            'iterations': len(iterations),
            'total_points': sum(iter_['n_points_added'] for iter_ in iterations),
            'total_improvement': total_improvement,
            'strategy': strategy_str,
            'batch_size': config.get('batch_size', 100),
            'theory': f"{config.get('method', 'B3LYP')}/{config.get('basis', '6-31G*')}",
            'iteration_history': [
                {
                    'iteration': iter_['iteration'],
                    'points_added': iter_['n_points_added'],
                    'rmse_after': iter_['model_rmse_after'],
                    'improvement_pct': iter_.get('improvement_pct')
                }
                for iter_ in iterations
            ]
        }


# Global dashboard instance
dashboard = None


@app.route('/')
def index():
    """Render main dashboard page."""
    return render_template_string(DASHBOARD_TEMPLATE)


@app.route('/api/status')
def api_status():
    """API endpoint for status data."""
    global dashboard
    
    if dashboard is None:
        return jsonify({
            'status': 'no_data',
            'message': 'Dashboard not initialized'
        })
    
    return jsonify(dashboard.get_status_data())


def run_dashboard(refinement_dir: Path, port: int = 5000, host: str = '127.0.0.1'):
    """
    Run the refinement dashboard.
    
    Args:
        refinement_dir: Directory containing refinement outputs
        port: Port to run dashboard on
        host: Host to bind to
    """
    global dashboard
    
    dashboard = RefinementDashboard(refinement_dir)
    
    print("=" * 70)
    print("  ML-PES REFINEMENT DASHBOARD")
    print("=" * 70)
    print(f"\n📂 Monitoring: {refinement_dir}")
    print(f"🌐 Dashboard URL: http://{host}:{port}")
    print(f"\nPress Ctrl+C to stop the server")
    print("=" * 70)
    
    app.run(host=host, port=port, debug=False)


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='ML-PES Refinement Dashboard')
    parser.add_argument('refinement_dir', type=Path, help='Refinement output directory')
    parser.add_argument('--port', type=int, default=5000, help='Port to run on')
    parser.add_argument('--host', default='127.0.0.1', help='Host to bind to')
    
    args = parser.parse_args()
    
    if not args.refinement_dir.exists():
        print(f"❌ Directory not found: {args.refinement_dir}")
        sys.exit(1)
    
    run_dashboard(args.refinement_dir, args.port, args.host)
