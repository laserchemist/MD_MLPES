# ML-PES Refinement Quick Reference

## 📁 Files Overview

### Core Modules
| File | Purpose | Key Classes/Functions |
|------|---------|----------------------|
| `normal_mode_sampler.py` | Normal mode analysis & sampling | `NormalModeAnalyzer`, `NormalModeSampler` |
| `gp_uncertainty.py` | GP uncertainty quantification | `GaussianProcessPES`, `UncertaintyPrediction` |
| `active_learning.py` | Active learning coordinator | `ActiveLearningCoordinator`, `RefinementConfig` |
| `refinement_dashboard.py` | Web monitoring dashboard | `RefinementDashboard`, Flask routes |

### Scripts
| File | Purpose |
|------|---------|
| `refine_mlpes.py` | Complete refinement workflow |
| `example_workflow.py` | Example demonstrating all components |
| `test_refinement_modules.py` | Unit tests |

### Documentation
| File | Content |
|------|---------|
| `README.md` | Comprehensive documentation |
| `QUICK_REFERENCE.md` | This file |

## 🚀 Common Commands

### Run Complete Refinement
```bash
python refine_mlpes.py \
    --model model.pkl \
    --training-data training_data.npz \
    --strategy combined \
    --batch-size 100 \
    --max-iterations 5 \
    --target-rmse 1.0
```

### Launch Dashboard
```bash
python refinement_dashboard.py refinement_output/
# Open http://localhost:5000
```

### Run Tests
```bash
python test_refinement_modules.py
```

### Run Example
```bash
python example_workflow.py
```

## 📊 Typical Workflow

```
1. Generate training data
   └─> python generate_training_data_COMPLETE_WORKING.py

2. Train initial ML-PES
   └─> python complete_workflow_v2.2.py

3. Refine ML-PES (THIS SYSTEM)
   └─> python refine_mlpes.py ...

4. Monitor progress
   └─> python refinement_dashboard.py ...

5. Use refined model
   └─> python compute_ir_spectrum_FIXED.py --model refined.pkl
```

## 🎯 Strategy Selection

| Strategy | Best For | Speed | Coverage |
|----------|----------|-------|----------|
| `normal_modes` | Vibrational properties | Fast | Systematic |
| `uncertainty` | Exploration | Medium | Adaptive |
| `combined` | Production models | Slower | Comprehensive |

## ⚙️ Key Parameters

### Normal Mode Sampling
- `--n-modes`: Number of modes (3-10)
- `--mode-displacement`: Max displacement in Å (0.1-0.3)

### Uncertainty-Based
- `--uncertainty-threshold`: Threshold in kcal/mol (3-10)

### General
- `--batch-size`: Points per iteration (50-200)
- `--max-iterations`: Stop after N iterations (3-10)
- `--target-rmse`: Convergence threshold (0.5-2.0 kcal/mol)

## 🔍 Output Files

```
refinement_YYYYMMDD_HHMMSS/
├── refinement_history.json      # Full iteration history
├── iteration_N_points.npz       # Points from iteration N
├── model_iteration_N.pkl        # Retrained model N
```

## 📈 Expected Performance

| Metric | Typical Value |
|--------|---------------|
| Initial RMSE | 3-10 kcal/mol |
| Target RMSE | 0.5-1.5 kcal/mol |
| Points per iteration | 50-100 |
| Iterations to converge | 3-5 |
| Time per iteration | 30-120 min |
| Total improvement | 30-60% |

## 🐛 Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| Import errors | Check all modules in same directory |
| PSI4 not found | Install PSI4 or check PATH |
| Memory errors | Reduce batch size |
| Slow GP training | Use fewer training points for GP |
| No improvement | Increase batch size, try different strategy |

## 💡 Pro Tips

1. **Start small**: Test with `--batch-size 20 --max-iterations 2` first
2. **Monitor**: Always run dashboard to track progress
3. **Save models**: Each iteration saves a model - test them individually
4. **Combine strategies**: `--strategy combined` usually works best
5. **Check tests**: Run unit tests after any modifications

## 📞 Quick Help

```bash
# Get help on any script
python refine_mlpes.py --help
python refinement_dashboard.py --help

# Run example to verify installation
python example_workflow.py

# Run tests to verify all modules work
python test_refinement_modules.py
```

## 🔗 Integration Points

This system integrates with your existing workflow:

| Existing File | Integration Point |
|---------------|------------------|
| `generate_training_data_COMPLETE_WORKING.py` | Provides training data |
| `complete_workflow_v2.2.py` | Provides initial model |
| `two_phase_workflow.py` | Can use refined model |
| `compute_ir_spectrum_FIXED.py` | Can use refined model |

## 📝 Quick Code Snippets

### Load Normal Mode Data
```python
from normal_mode_sampler import load_normal_mode_data
nm_data = load_normal_mode_data('normal_modes.npz')
```

### Check Uncertainty
```python
from gp_uncertainty import GaussianProcessPES
gp = GaussianProcessPES.load('gp_model.pkl', descriptor_func, symbols)
pred = gp.predict_with_uncertainty(coords)
print(f"Uncertainty: {pred.energy_uncertainty_kcal():.2f} kcal/mol")
```

### View Refinement History
```python
import json
with open('refinement_history.json') as f:
    history = json.load(f)
print(f"Iterations: {len(history['iterations'])}")
print(f"Final RMSE: {history['iterations'][-1]['model_rmse_after']:.4f}")
```

---

**Quick Start**: Run `python example_workflow.py` to see everything in action!
