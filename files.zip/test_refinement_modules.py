#!/usr/bin/env python3
"""
Unit Tests for ML-PES Refinement Modules
=========================================
Comprehensive test suite for:
- Normal mode sampling
- GP uncertainty quantification
- Active learning coordinator

Author: Jonathan
Date: 2026-01-20
Version: 1.0
"""

import unittest
import numpy as np
from pathlib import Path
import tempfile
import shutil


class TestNormalModeSampler(unittest.TestCase):
    """Test normal mode sampling functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Simple water molecule
        self.symbols = ['O', 'H', 'H']
        self.coords = np.array([
            [0.0, 0.0, 0.0],
            [0.0, 0.757, 0.586],
            [0.0, -0.757, 0.586]
        ])
        
        # Mock energy calculator
        class MockCalculator:
            def predict_with_forces(self, coords):
                # Harmonic potential (simple test)
                energy = 0.5 * np.sum((coords - self.coords)**2)
                forces = -(coords - self.coords)
                return energy, forces
            
            coords = self.coords
        
        self.calculator = MockCalculator()
    
    def test_normal_mode_analyzer_creation(self):
        """Test NormalModeAnalyzer initialization."""
        from normal_mode_sampler import NormalModeAnalyzer
        
        analyzer = NormalModeAnalyzer(self.symbols, self.coords)
        
        self.assertEqual(analyzer.n_atoms, 3)
        self.assertEqual(len(analyzer.masses), 3)
        self.assertTrue(np.allclose(analyzer.reference_coords, self.coords))
    
    def test_hessian_computation(self):
        """Test numerical Hessian computation."""
        from normal_mode_sampler import NormalModeAnalyzer
        
        analyzer = NormalModeAnalyzer(self.symbols, self.coords)
        hessian = analyzer.compute_hessian_numerical(self.calculator, delta=0.01)
        
        # Check shape
        self.assertEqual(hessian.shape, (9, 9))
        
        # Check symmetry
        self.assertTrue(np.allclose(hessian, hessian.T, atol=1e-6))
    
    def test_normal_mode_analysis(self):
        """Test normal mode diagonalization."""
        from normal_mode_sampler import NormalModeAnalyzer
        
        analyzer = NormalModeAnalyzer(self.symbols, self.coords)
        hessian = analyzer.compute_hessian_numerical(self.calculator, delta=0.01)
        nm_data = analyzer.analyze_normal_modes(hessian)
        
        # Check output structure
        self.assertEqual(len(nm_data.frequencies), 9)
        self.assertEqual(nm_data.modes.shape, (9, 9))
        self.assertEqual(len(nm_data.symbols), 3)
        
        # For harmonic potential, should have 6 zero frequencies (translations + rotations)
        # and 3 real frequencies
        near_zero = np.sum(np.abs(nm_data.frequencies) < 50)
        self.assertGreaterEqual(near_zero, 3)  # At least translations
    
    def test_normal_mode_sampler_single_mode(self):
        """Test sampling along a single mode."""
        from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler
        
        analyzer = NormalModeAnalyzer(self.symbols, self.coords)
        hessian = analyzer.compute_hessian_numerical(self.calculator, delta=0.01)
        nm_data = analyzer.analyze_normal_modes(hessian)
        
        sampler = NormalModeSampler(nm_data)
        
        # Sample along mode 0
        displacements = np.array([-0.2, -0.1, 0.0, 0.1, 0.2])
        coords_samples = sampler.generate_samples_single_mode(
            mode_index=0,
            displacements=displacements
        )
        
        # Check shape
        self.assertEqual(coords_samples.shape, (5, 3, 3))
        
        # Middle point should be reference
        self.assertTrue(np.allclose(coords_samples[2], self.coords, atol=1e-10))
    
    def test_save_load_normal_mode_data(self):
        """Test saving and loading normal mode data."""
        from normal_mode_sampler import (NormalModeAnalyzer, 
                                         save_normal_mode_data,
                                         load_normal_mode_data)
        
        analyzer = NormalModeAnalyzer(self.symbols, self.coords)
        hessian = analyzer.compute_hessian_numerical(self.calculator, delta=0.01)
        nm_data = analyzer.analyze_normal_modes(hessian)
        
        # Save
        with tempfile.NamedTemporaryFile(suffix='.npz', delete=False) as tmp:
            save_normal_mode_data(nm_data, Path(tmp.name))
            
            # Load
            loaded_data = load_normal_mode_data(Path(tmp.name))
            
            # Compare
            self.assertTrue(np.allclose(loaded_data.frequencies, nm_data.frequencies))
            self.assertTrue(np.allclose(loaded_data.modes, nm_data.modes))
            self.assertEqual(loaded_data.symbols, nm_data.symbols)
            
            # Cleanup
            Path(tmp.name).unlink()


class TestGPUncertainty(unittest.TestCase):
    """Test Gaussian Process uncertainty quantification."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Generate synthetic training data
        np.random.seed(42)
        
        self.symbols = ['H', 'H']
        
        # Generate coordinates (1D potential for simplicity)
        x = np.linspace(0.5, 2.0, 20)
        self.coords_train = np.array([
            [[0.0, 0.0, 0.0], [xi, 0.0, 0.0]] for xi in x
        ])
        
        # Harmonic potential
        k = 1.0
        r0 = 1.0
        r = x
        self.energies_train = 0.5 * k * (r - r0)**2
    
    def test_gp_initialization(self):
        """Test GP model initialization."""
        from gp_uncertainty import GaussianProcessPES
        
        gp = GaussianProcessPES(kernel='rbf', alpha=1e-5)
        
        self.assertEqual(gp.kernel_type, 'rbf')
        self.assertFalse(gp.is_trained)
    
    def test_gp_training(self):
        """Test GP model training."""
        from gp_uncertainty import GaussianProcessPES
        
        # Descriptor function
        def descriptor(symbols, coords):
            return coords.flatten()
        
        gp = GaussianProcessPES(kernel='rbf', alpha=1e-5)
        gp.fit(
            coordinates=self.coords_train,
            energies=self.energies_train,
            descriptor_func=descriptor,
            symbols=self.symbols
        )
        
        self.assertTrue(gp.is_trained)
    
    def test_gp_prediction(self):
        """Test GP predictions with uncertainty."""
        from gp_uncertainty import GaussianProcessPES
        
        def descriptor(symbols, coords):
            return coords.flatten()
        
        gp = GaussianProcessPES(kernel='rbf', alpha=1e-5)
        gp.fit(
            coordinates=self.coords_train,
            energies=self.energies_train,
            descriptor_func=descriptor,
            symbols=self.symbols
        )
        
        # Predict on training point (should have low uncertainty)
        test_coords = self.coords_train[10]
        pred = gp.predict_with_uncertainty(test_coords)
        
        # Should be close to training value
        self.assertLess(abs(pred.mean_energy - self.energies_train[10]), 0.1)
        
        # Uncertainty should be small
        self.assertLess(pred.std_energy, 0.1)
    
    def test_uncertainty_tracker(self):
        """Test uncertainty tracking."""
        from gp_uncertainty import UncertaintyTracker, UncertaintyPrediction
        
        tracker = UncertaintyTracker(warning_threshold_kcal=5.0)
        
        # Record some predictions
        for i in range(10):
            pred = UncertaintyPrediction(
                mean_energy=0.0,
                std_energy=i * 0.001  # Increasing uncertainty
            )
            tracker.record_prediction(pred)
        
        stats = tracker.get_statistics()
        
        self.assertEqual(stats['n_predictions'], 10)
        self.assertGreater(stats['mean_uncertainty_kcal'], 0.0)


class TestActiveLearning(unittest.TestCase):
    """Test active learning coordinator."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create temporary directory
        self.test_dir = Path(tempfile.mkdtemp())
        
        # Simple test system
        self.symbols = ['H', 'H']
        self.coords = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
        
        # Mock ML-PES model
        class MockMLPES:
            def __init__(self):
                self.symbols = ['H', 'H']
                self.method = 'B3LYP'
                self.basis = '6-31G*'
            
            def predict_with_forces(self, coords):
                energy = 0.5 * np.sum(coords**2)
                forces = -coords
                return energy, forces
        
        self.ml_pes = MockMLPES()
    
    def tearDown(self):
        """Clean up test directory."""
        shutil.rmtree(self.test_dir)
    
    def test_refinement_config_creation(self):
        """Test RefinementConfig creation."""
        from active_learning import RefinementConfig
        
        config = RefinementConfig(
            use_normal_modes=True,
            use_uncertainty=True,
            batch_size=50,
            output_dir=self.test_dir
        )
        
        self.assertTrue(config.use_normal_modes)
        self.assertEqual(config.batch_size, 50)
        self.assertEqual(config.output_dir, self.test_dir)
    
    def test_coordinator_initialization(self):
        """Test ActiveLearningCoordinator initialization."""
        from active_learning import ActiveLearningCoordinator, RefinementConfig
        
        config = RefinementConfig(output_dir=self.test_dir)
        
        coordinator = ActiveLearningCoordinator(
            config=config,
            ml_pes_model=self.ml_pes,
            reference_coords=self.coords,
            symbols=self.symbols
        )
        
        self.assertEqual(coordinator.symbols, self.symbols)
        self.assertTrue(coordinator.config.output_dir.exists())


class TestIntegration(unittest.TestCase):
    """Integration tests for complete workflow."""
    
    def setUp(self):
        """Set up integration test environment."""
        self.test_dir = Path(tempfile.mkdtemp())
    
    def tearDown(self):
        """Clean up."""
        shutil.rmtree(self.test_dir)
    
    def test_end_to_end_normal_mode_workflow(self):
        """Test complete normal mode workflow."""
        from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler
        
        # Test data
        symbols = ['H', 'H']
        coords = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
        
        class MockCalc:
            def predict_with_forces(self, coords):
                return 0.5 * np.sum(coords**2), -coords
        
        calc = MockCalc()
        
        # Analyze
        analyzer = NormalModeAnalyzer(symbols, coords)
        hessian = analyzer.compute_hessian_numerical(calc, delta=0.01)
        nm_data = analyzer.analyze_normal_modes(hessian)
        
        # Sample
        sampler = NormalModeSampler(nm_data)
        mode_indices = sampler.select_important_modes(
            min_frequency=50.0,
            n_modes=2
        )
        
        if len(mode_indices) > 0:
            coords_samples, metadata = sampler.generate_samples_multiple_modes(
                mode_indices=mode_indices[:1],
                n_points_per_mode=5,
                strategy='grid'
            )
            
            # Check output
            self.assertEqual(coords_samples.shape[0], 5)
            self.assertEqual(len(metadata), 5)


def run_tests(verbosity=2):
    """Run all tests."""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(TestNormalModeSampler))
    suite.addTests(loader.loadTestsFromTestCase(TestGPUncertainty))
    suite.addTests(loader.loadTestsFromTestCase(TestActiveLearning))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=verbosity)
    result = runner.run(suite)
    
    return result


if __name__ == '__main__':
    print("=" * 80)
    print("  ML-PES REFINEMENT MODULE UNIT TESTS")
    print("=" * 80)
    print()
    
    result = run_tests()
    
    print("\n" + "=" * 80)
    print("  TEST SUMMARY")
    print("=" * 80)
    print(f"\nTests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.wasSuccessful():
        print("\n✅ ALL TESTS PASSED!")
    else:
        print("\n❌ SOME TESTS FAILED")
        
        if result.failures:
            print("\nFailures:")
            for test, traceback in result.failures:
                print(f"  - {test}")
        
        if result.errors:
            print("\nErrors:")
            for test, traceback in result.errors:
                print(f"  - {test}")
