#!/usr/bin/env python3
"""
Normal Mode Sampling for ML-PES Refinement
===========================================
Generate systematic distortions along normal modes for targeted PES refinement.

This module computes vibrational normal modes and systematically samples along
them to refine ML potential energy surfaces in chemically relevant regions.

Author: Jonathan
Date: 2026-01-20
Version: 1.0
"""

import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import json
from dataclasses import dataclass


# Physical constants
AMU_TO_AU = 1822.888  # Conversion factor for atomic mass units to atomic units


@dataclass
class NormalModeData:
    """Container for normal mode analysis results."""
    frequencies: np.ndarray  # Frequencies in cm⁻¹
    modes: np.ndarray  # Normal mode vectors (3N x 3N)
    mass_weighted_hessian: np.ndarray  # Mass-weighted Hessian matrix
    symbols: List[str]  # Atomic symbols
    reference_coords: np.ndarray  # Reference geometry (Å)
    
    def __post_init__(self):
        """Validate data consistency."""
        n_atoms = len(self.symbols)
        assert self.modes.shape == (3 * n_atoms, 3 * n_atoms), \
            f"Modes shape mismatch: {self.modes.shape} vs {(3*n_atoms, 3*n_atoms)}"
        assert len(self.frequencies) == 3 * n_atoms, \
            f"Frequency count mismatch: {len(self.frequencies)} vs {3*n_atoms}"


class NormalModeAnalyzer:
    """
    Compute vibrational normal modes from Hessian matrix.
    
    This class handles:
    - Mass-weighted Hessian diagonalization
    - Frequency calculation
    - Mode normalization
    - Identification of imaginary frequencies
    """
    
    def __init__(self, symbols: List[str], reference_coords: np.ndarray):
        """
        Initialize normal mode analyzer.
        
        Args:
            symbols: Atomic symbols
            reference_coords: Reference geometry in Angstroms (N_atoms, 3)
        """
        self.symbols = symbols
        self.reference_coords = reference_coords.copy()
        self.n_atoms = len(symbols)
        
        # Atomic masses (amu)
        self.mass_dict = {
            'H': 1.008, 'C': 12.011, 'N': 14.007, 'O': 15.999,
            'F': 18.998, 'S': 32.06, 'Cl': 35.45, 'P': 30.974
        }
        self.masses = np.array([self.mass_dict.get(s, 12.0) for s in symbols])
    
    def compute_hessian_numerical(self, energy_calculator, delta: float = 0.005) -> np.ndarray:
        """
        Compute Hessian numerically using central finite differences.
        
        Args:
            energy_calculator: Object with predict_with_forces(coords) method
            delta: Displacement in Angstroms
            
        Returns:
            Hessian matrix (3N x 3N) in Hartree/Bohr²
        """
        print(f"\n{'='*60}")
        print(f"Computing Numerical Hessian")
        print(f"{'='*60}")
        print(f"  Method: Central finite differences")
        print(f"  Delta: {delta} Å")
        print(f"  Atoms: {self.n_atoms}")
        print(f"  Matrix size: {3*self.n_atoms} × {3*self.n_atoms}")
        
        hessian = np.zeros((3 * self.n_atoms, 3 * self.n_atoms))
        
        # Convert delta to Bohr for force calculations
        delta_bohr = delta / 0.529177
        
        try:
            from tqdm import tqdm
            use_tqdm = True
        except ImportError:
            use_tqdm = False
        
        # Progress tracking
        total_calcs = 3 * self.n_atoms
        iterator = tqdm(range(total_calcs), desc="Hessian") if use_tqdm else range(total_calcs)
        
        for idx in iterator:
            i = idx // 3  # Atom index
            j = idx % 3   # Cartesian component (0=x, 1=y, 2=z)
            
            # Perturb in positive direction
            coords_plus = self.reference_coords.copy()
            coords_plus[i, j] += delta
            _, forces_plus = energy_calculator.predict_with_forces(coords_plus)
            
            # Perturb in negative direction
            coords_minus = self.reference_coords.copy()
            coords_minus[i, j] -= delta
            _, forces_minus = energy_calculator.predict_with_forces(coords_minus)
            
            # Central difference: d²E/dxᵢdxⱼ = -(dFⱼ/dxᵢ)
            # Forces are already negative gradients: F = -dE/dx
            # So: d²E/dxᵢdxⱼ = -(Fⱼ(+Δ) - Fⱼ(-Δ))/(2Δ)
            force_diff = (forces_plus - forces_minus) / (2 * delta_bohr)
            
            # Fill Hessian column
            hessian[:, idx] = -force_diff.flatten()
        
        # Symmetrize Hessian (should already be symmetric, but enforce)
        hessian = 0.5 * (hessian + hessian.T)
        
        print(f"\n✓ Hessian computed")
        print(f"  Symmetry check: max |H - Hᵀ| = {np.max(np.abs(hessian - hessian.T)):.2e}")
        
        return hessian
    
    def analyze_normal_modes(self, hessian: np.ndarray) -> NormalModeData:
        """
        Diagonalize mass-weighted Hessian to get normal modes.
        
        Args:
            hessian: Hessian matrix (3N x 3N) in Hartree/Bohr²
            
        Returns:
            NormalModeData object with frequencies and modes
        """
        print(f"\n{'='*60}")
        print(f"Normal Mode Analysis")
        print(f"{'='*60}")
        
        # Create mass-weighting matrix: M^(-1/2)
        mass_weights = np.repeat(self.masses * AMU_TO_AU, 3)
        M_inv_sqrt = np.diag(1.0 / np.sqrt(mass_weights))
        
        # Mass-weighted Hessian: H̃ = M^(-1/2) H M^(-1/2)
        H_mw = M_inv_sqrt @ hessian @ M_inv_sqrt
        
        # Diagonalize
        eigenvalues, eigenvectors = np.linalg.eigh(H_mw)
        
        # Convert eigenvalues to frequencies
        # ω² = λ (in atomic units)
        # ν (cm⁻¹) = ω / (2πc) where c is speed of light
        
        # Handle imaginary frequencies (negative eigenvalues)
        frequencies = np.zeros_like(eigenvalues)
        for i, ev in enumerate(eigenvalues):
            if ev >= 0:
                omega = np.sqrt(ev)
            else:
                omega = -np.sqrt(-ev)  # Imaginary frequency (negative)
            
            # Convert to cm⁻¹
            # 1 au of frequency = 2.1947e5 cm⁻¹
            frequencies[i] = omega * 2.1947e5
        
        # Un-mass-weight the eigenvectors to get Cartesian displacements
        modes = M_inv_sqrt @ eigenvectors
        
        # Normalize modes
        for i in range(modes.shape[1]):
            norm = np.linalg.norm(modes[:, i])
            if norm > 1e-10:
                modes[:, i] /= norm
        
        # Statistics
        n_imaginary = np.sum(frequencies < 0)
        n_near_zero = np.sum(np.abs(frequencies) < 10)  # < 10 cm⁻¹
        
        print(f"\n✓ Normal modes computed")
        print(f"  Total modes: {len(frequencies)}")
        print(f"  Imaginary frequencies: {n_imaginary}")
        print(f"  Near-zero frequencies: {n_near_zero} (< 10 cm⁻¹)")
        
        if n_imaginary > 0:
            print(f"\n⚠️  WARNING: {n_imaginary} imaginary frequencies detected!")
            print(f"  This indicates the reference geometry is not a minimum.")
            print(f"  Imaginary modes:")
            for i, freq in enumerate(frequencies):
                if freq < 0:
                    print(f"    Mode {i+1}: {freq:.2f} cm⁻¹")
        
        # Show frequency range
        real_freqs = frequencies[frequencies > 10]  # Exclude translations/rotations
        if len(real_freqs) > 0:
            print(f"\n  Frequency range: {real_freqs.min():.1f} - {real_freqs.max():.1f} cm⁻¹")
            print(f"  Mean frequency: {real_freqs.mean():.1f} cm⁻¹")
        
        return NormalModeData(
            frequencies=frequencies,
            modes=modes,
            mass_weighted_hessian=H_mw,
            symbols=self.symbols,
            reference_coords=self.reference_coords
        )


class NormalModeSampler:
    """
    Generate training points by systematic displacements along normal modes.
    
    This provides targeted sampling for ML-PES refinement in chemically
    relevant regions of configuration space.
    """
    
    def __init__(self, normal_mode_data: NormalModeData):
        """
        Initialize sampler with normal mode data.
        
        Args:
            normal_mode_data: NormalModeData object from analysis
        """
        self.nm_data = normal_mode_data
        self.n_atoms = len(normal_mode_data.symbols)
    
    def generate_samples_single_mode(
        self,
        mode_index: int,
        displacements: np.ndarray,
        units: str = 'angstrom'
    ) -> np.ndarray:
        """
        Generate samples along a single normal mode.
        
        Args:
            mode_index: Index of normal mode (0-based)
            displacements: Array of displacement amplitudes
            units: 'angstrom' or 'amu_bohr' (mass-weighted)
            
        Returns:
            Coordinates array (n_displacements, n_atoms, 3)
        """
        mode = self.nm_data.modes[:, mode_index].reshape(self.n_atoms, 3)
        
        # Normalize mode to unit displacement in Angstroms
        if units == 'angstrom':
            mode_norm = mode / np.linalg.norm(mode)
        else:
            mode_norm = mode
        
        coords_list = []
        for d in displacements:
            coords = self.nm_data.reference_coords + d * mode_norm
            coords_list.append(coords)
        
        return np.array(coords_list)
    
    def generate_samples_multiple_modes(
        self,
        mode_indices: List[int],
        n_points_per_mode: int = 11,
        max_displacement: float = 0.2,
        strategy: str = 'grid'
    ) -> Tuple[np.ndarray, List[Dict]]:
        """
        Generate samples along multiple normal modes.
        
        Args:
            mode_indices: Indices of modes to sample
            n_points_per_mode: Number of points per mode
            max_displacement: Maximum displacement (Å)
            strategy: 'grid' (systematic grid) or 'random' (random combinations)
            
        Returns:
            coords: Array of coordinates (n_samples, n_atoms, 3)
            metadata: List of dictionaries with sampling info
        """
        print(f"\n{'='*60}")
        print(f"Generating Normal Mode Samples")
        print(f"{'='*60}")
        print(f"  Strategy: {strategy}")
        print(f"  Modes: {len(mode_indices)}")
        print(f"  Points per mode: {n_points_per_mode}")
        print(f"  Max displacement: {max_displacement} Å")
        
        # Create displacement range
        displacements_1d = np.linspace(-max_displacement, max_displacement, n_points_per_mode)
        
        coords_list = []
        metadata_list = []
        
        if strategy == 'grid':
            # Systematic grid over all mode combinations
            print(f"\n  Generating {len(mode_indices)}D grid...")
            
            # Create meshgrid for all modes
            grids = np.meshgrid(*[displacements_1d] * len(mode_indices), indexing='ij')
            
            # Flatten grids
            n_samples = n_points_per_mode ** len(mode_indices)
            print(f"  Total samples: {n_samples}")
            
            for i in range(n_samples):
                # Get displacement for each mode
                indices = np.unravel_index(i, [n_points_per_mode] * len(mode_indices))
                
                # Start from reference
                coords = self.nm_data.reference_coords.copy()
                
                mode_displacements = {}
                for j, mode_idx in enumerate(mode_indices):
                    d = displacements_1d[indices[j]]
                    mode = self.nm_data.modes[:, mode_idx].reshape(self.n_atoms, 3)
                    mode_norm = mode / np.linalg.norm(mode)
                    
                    coords += d * mode_norm
                    mode_displacements[f'mode_{mode_idx}'] = float(d)
                
                coords_list.append(coords)
                metadata_list.append({
                    'sample_id': i,
                    'strategy': strategy,
                    'mode_displacements': mode_displacements
                })
        
        elif strategy == 'random':
            # Random sampling
            n_samples = n_points_per_mode ** len(mode_indices)  # Same total as grid
            print(f"  Generating {n_samples} random samples...")
            
            for i in range(n_samples):
                coords = self.nm_data.reference_coords.copy()
                
                mode_displacements = {}
                for mode_idx in mode_indices:
                    d = np.random.uniform(-max_displacement, max_displacement)
                    mode = self.nm_data.modes[:, mode_idx].reshape(self.n_atoms, 3)
                    mode_norm = mode / np.linalg.norm(mode)
                    
                    coords += d * mode_norm
                    mode_displacements[f'mode_{mode_idx}'] = float(d)
                
                coords_list.append(coords)
                metadata_list.append({
                    'sample_id': i,
                    'strategy': strategy,
                    'mode_displacements': mode_displacements
                })
        
        else:
            raise ValueError(f"Unknown strategy: {strategy}")
        
        coords_array = np.array(coords_list)
        
        print(f"\n✓ Generated {len(coords_array)} configurations")
        
        return coords_array, metadata_list
    
    def select_important_modes(
        self,
        min_frequency: float = 50.0,
        max_frequency: float = 4000.0,
        n_modes: Optional[int] = None
    ) -> List[int]:
        """
        Select important vibrational modes for sampling.
        
        Args:
            min_frequency: Minimum frequency (cm⁻¹) to include
            max_frequency: Maximum frequency (cm⁻¹) to include
            n_modes: Maximum number of modes to select (None = all)
            
        Returns:
            List of mode indices
        """
        # Filter by frequency range
        freq = self.nm_data.frequencies
        mask = (freq >= min_frequency) & (freq <= max_frequency)
        
        valid_indices = np.where(mask)[0]
        
        # Sort by frequency (low to high - more important for dynamics)
        sorted_indices = valid_indices[np.argsort(freq[valid_indices])]
        
        # Limit number if requested
        if n_modes is not None:
            sorted_indices = sorted_indices[:n_modes]
        
        print(f"\n{'='*60}")
        print(f"Selected Important Modes")
        print(f"{'='*60}")
        print(f"  Frequency range: {min_frequency} - {max_frequency} cm⁻¹")
        print(f"  Selected modes: {len(sorted_indices)}")
        
        if len(sorted_indices) > 0:
            print(f"\n  Mode details:")
            for i in sorted_indices[:10]:  # Show first 10
                print(f"    Mode {i+1}: {freq[i]:.1f} cm⁻¹")
            if len(sorted_indices) > 10:
                print(f"    ... and {len(sorted_indices)-10} more")
        
        return sorted_indices.tolist()


def save_normal_mode_data(nm_data: NormalModeData, filepath: Path) -> None:
    """Save normal mode data to npz file."""
    np.savez(
        filepath,
        frequencies=nm_data.frequencies,
        modes=nm_data.modes,
        mass_weighted_hessian=nm_data.mass_weighted_hessian,
        symbols=nm_data.symbols,
        reference_coords=nm_data.reference_coords
    )
    print(f"\n✓ Saved normal mode data: {filepath}")


def load_normal_mode_data(filepath: Path) -> NormalModeData:
    """Load normal mode data from npz file."""
    data = np.load(filepath, allow_pickle=True)
    
    return NormalModeData(
        frequencies=data['frequencies'],
        modes=data['modes'],
        mass_weighted_hessian=data['mass_weighted_hessian'],
        symbols=list(data['symbols']),
        reference_coords=data['reference_coords']
    )


if __name__ == "__main__":
    print("Normal Mode Sampling Module")
    print("=" * 60)
    print("\nThis module provides:")
    print("  • NormalModeAnalyzer - Compute normal modes from Hessian")
    print("  • NormalModeSampler - Generate training points")
    print("  • Smart mode selection")
    print("\nUsage:")
    print("  from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler")
    print("\nSee documentation for examples.")
