#!/usr/bin/env python3
"""
Active Learning Coordinator for ML-PES Refinement
==================================================
Orchestrates adaptive refinement using multiple strategies:
- Normal mode sampling
- Gaussian Process uncertainty quantification
- Error-based selection from MD trajectories

Author: Jonathan
Date: 2026-01-20
Version: 1.0
"""

import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
import json
import pickle


@dataclass
class RefinementConfig:
    """Configuration for refinement workflow."""
    
    # Normal mode sampling
    use_normal_modes: bool = True
    n_normal_modes: int = 5
    normal_mode_points: int = 11
    normal_mode_displacement: float = 0.2  # Angstroms
    
    # Uncertainty-based sampling
    use_uncertainty: bool = True
    uncertainty_threshold_kcal: float = 5.0
    max_uncertainty_points: int = 50
    
    # Error-based sampling (from MD validation)
    use_error_based: bool = True
    error_threshold_kcal: float = 5.0
    max_error_points: int = 50
    
    # Refinement strategy
    batch_size: int = 100  # Points to add per iteration
    max_iterations: int = 5
    convergence_rmse_kcal: float = 1.0  # Stop when RMSE below this
    
    # PSI4 settings
    method: str = 'B3LYP'
    basis: str = '6-31G*'
    
    # Output
    output_dir: Path = field(default_factory=lambda: Path('refinement_outputs'))


@dataclass
class RefinementResult:
    """Results from a refinement iteration."""
    iteration: int
    n_points_added: int
    source_breakdown: Dict[str, int]  # How many from each source
    coordinates_added: np.ndarray
    energies_added: np.ndarray
    forces_added: np.ndarray
    model_rmse_before: float
    model_rmse_after: float
    improvement_pct: float


class ActiveLearningCoordinator:
    """
    Coordinate active learning refinement workflow.
    
    This class orchestrates:
    1. Normal mode sampling for systematic coverage
    2. GP uncertainty for exploration
    3. Error-based sampling from MD validation
    """
    
    def __init__(
        self,
        config: RefinementConfig,
        ml_pes_model,
        reference_coords: np.ndarray,
        symbols: List[str]
    ):
        """
        Initialize coordinator.
        
        Args:
            config: Refinement configuration
            ml_pes_model: Current ML-PES model with predict_with_forces()
            reference_coords: Reference geometry (Angstroms)
            symbols: Atomic symbols
        """
        self.config = config
        self.ml_pes_model = ml_pes_model
        self.reference_coords = reference_coords
        self.symbols = symbols
        
        # Create output directory
        self.config.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.normal_mode_sampler = None
        self.gp_model = None
        self.uncertainty_tracker = None
        
        # History
        self.refinement_history = []
        
        print(f"\n{'='*70}")
        print(f"Active Learning Coordinator Initialized")
        print(f"{'='*70}")
        print(f"  Output: {self.config.output_dir}")
        print(f"\n  Strategies enabled:")
        print(f"    Normal modes: {self.config.use_normal_modes}")
        print(f"    Uncertainty: {self.config.use_uncertainty}")
        print(f"    Error-based: {self.config.use_error_based}")
        print(f"\n  Refinement settings:")
        print(f"    Batch size: {self.config.batch_size} points/iteration")
        print(f"    Max iterations: {self.config.max_iterations}")
        print(f"    Target RMSE: {self.config.convergence_rmse_kcal} kcal/mol")
    
    def setup_normal_mode_sampling(self):
        """Initialize normal mode sampling."""
        from normal_mode_sampler import NormalModeAnalyzer, NormalModeSampler
        
        print(f"\n{'='*70}")
        print(f"Setting Up Normal Mode Sampling")
        print(f"{'='*70}")
        
        # Compute normal modes
        analyzer = NormalModeAnalyzer(self.symbols, self.reference_coords)
        
        # Compute Hessian numerically
        hessian = analyzer.compute_hessian_numerical(self.ml_pes_model)
        
        # Analyze modes
        nm_data = analyzer.analyze_normal_modes(hessian)
        
        # Create sampler
        self.normal_mode_sampler = NormalModeSampler(nm_data)
        
        # Select important modes
        mode_indices = self.normal_mode_sampler.select_important_modes(
            min_frequency=50.0,
            max_frequency=4000.0,
            n_modes=self.config.n_normal_modes
        )
        
        self.selected_mode_indices = mode_indices
        
        print(f"\n✓ Normal mode sampling ready")
        print(f"  Selected {len(mode_indices)} modes for sampling")
    
    def setup_uncertainty_model(self, training_coords: np.ndarray, training_energies: np.ndarray):
        """Initialize GP uncertainty model."""
        from gp_uncertainty import GaussianProcessPES, UncertaintyTracker
        
        print(f"\n{'='*70}")
        print(f"Setting Up Uncertainty Quantification")
        print(f"{'='*70}")
        
        # Create GP model
        self.gp_model = GaussianProcessPES(
            kernel='rbf',
            alpha=1e-5,
            normalize_y=True
        )
        
        # Set descriptor (use same as ML-PES)
        from normal_mode_sampler import compute_coulomb_matrix
        
        def descriptor_func(symbols, coords):
            atomic_numbers = {'H': 1, 'C': 6, 'N': 7, 'O': 8, 'F': 9, 'S': 16}
            Z = np.array([atomic_numbers.get(s, 0) for s in symbols])
            n_atoms = len(symbols)
            cm = np.zeros((n_atoms, n_atoms))
            
            for i in range(n_atoms):
                for j in range(n_atoms):
                    if i == j:
                        cm[i, j] = 0.5 * Z[i]**2.4
                    else:
                        r_ij = np.linalg.norm(coords[i] - coords[j])
                        cm[i, j] = Z[i] * Z[j] / (r_ij + 1e-10)
            
            return cm[np.triu_indices(n_atoms)]
        
        # Fit GP
        self.gp_model.fit(
            coordinates=training_coords,
            energies=training_energies,
            descriptor_func=descriptor_func,
            symbols=self.symbols
        )
        
        # Create tracker
        self.uncertainty_tracker = UncertaintyTracker(
            warning_threshold_kcal=self.config.uncertainty_threshold_kcal
        )
        
        print(f"\n✓ GP uncertainty model ready")
    
    def generate_candidate_points_normal_modes(self) -> Tuple[np.ndarray, List[Dict]]:
        """Generate candidate points from normal mode sampling."""
        if self.normal_mode_sampler is None:
            raise RuntimeError("Normal mode sampling not set up")
        
        print(f"\n  [Normal Mode Sampling]")
        
        coords, metadata = self.normal_mode_sampler.generate_samples_multiple_modes(
            mode_indices=self.selected_mode_indices,
            n_points_per_mode=self.config.normal_mode_points,
            max_displacement=self.config.normal_mode_displacement,
            strategy='grid'
        )
        
        # Add source tag
        for m in metadata:
            m['source'] = 'normal_modes'
        
        return coords, metadata
    
    def generate_candidate_points_md_exploration(
        self,
        n_candidates: int = 1000,
        temperature: float = 300.0,
        n_steps: int = 500
    ) -> Tuple[np.ndarray, List[Dict]]:
        """
        Generate candidate points by running exploratory MD.
        
        This uses ML-PES to quickly generate diverse configurations.
        """
        print(f"\n  [MD Exploration]")
        print(f"    Temperature: {temperature} K")
        print(f"    Steps: {n_steps}")
        
        # Simple MD with ML-PES
        coords_current = self.reference_coords.copy()
        
        # Atomic masses
        mass_dict = {'H': 1.008, 'C': 12.011, 'N': 14.007, 'O': 15.999, 'F': 18.998}
        masses = np.array([mass_dict.get(s, 12.0) for s in self.symbols]) * 1822.888  # to a.u.
        
        # Initialize velocities
        kB = 1.380649e-23  # J/K
        velocities = np.random.randn(len(self.symbols), 3)
        velocities -= velocities.mean(axis=0)
        
        # Scale to temperature
        KE_target = 1.5 * len(self.symbols) * kB * temperature
        mass_kg = masses / 1822.888 * 1.66053906660e-27
        KE_current = 0.5 * np.sum(mass_kg[:, np.newaxis] * velocities**2)
        if KE_current > 0:
            velocities *= np.sqrt(KE_target / KE_current)
        
        # Run MD and collect snapshots
        dt = 0.5e-15  # 0.5 fs in seconds
        snapshot_every = max(1, n_steps // n_candidates)
        
        coords_list = []
        metadata_list = []
        
        for step in range(n_steps):
            # Velocity Verlet
            _, forces = self.ml_pes_model.predict_with_forces(coords_current)
            
            # Convert forces (Hartree/Angstrom to m/s²)
            FORCE_CONVERSION = (4.3597447222071e-18 / 1e-10) / 1.66053906660e-27
            accel = (forces / (masses / 1822.888)[:, np.newaxis]) * FORCE_CONVERSION
            
            velocities += 0.5 * accel * dt
            coords_current += velocities * dt / 1e-10  # m to Angstrom
            
            _, forces_new = self.ml_pes_model.predict_with_forces(coords_current)
            accel_new = (forces_new / (masses / 1822.888)[:, np.newaxis]) * FORCE_CONVERSION
            velocities += 0.5 * accel_new * dt
            
            # Save snapshot
            if step % snapshot_every == 0:
                coords_list.append(coords_current.copy())
                metadata_list.append({
                    'source': 'md_exploration',
                    'step': step,
                    'temperature': temperature
                })
        
        coords_array = np.array(coords_list)
        
        print(f"    Generated {len(coords_array)} candidates")
        
        return coords_array, metadata_list
    
    def select_points_by_uncertainty(
        self,
        candidate_coords: np.ndarray,
        candidate_metadata: List[Dict]
    ) -> Tuple[np.ndarray, List[Dict], np.ndarray]:
        """Select points with high GP uncertainty."""
        if self.gp_model is None:
            raise RuntimeError("GP model not set up")
        
        print(f"\n  [Uncertainty Selection]")
        print(f"    Candidates: {len(candidate_coords)}")
        print(f"    Threshold: {self.config.uncertainty_threshold_kcal} kcal/mol")
        
        # Get uncertainties
        _, uncertainties = self.gp_model.predict_batch_with_uncertainty(candidate_coords)
        uncertainties_kcal = uncertainties * 627.509
        
        # Select high uncertainty
        if self.config.max_uncertainty_points > 0:
            # Top N
            indices = np.argsort(uncertainties_kcal)[::-1][:self.config.max_uncertainty_points]
        else:
            # All above threshold
            indices = np.where(uncertainties_kcal > self.config.uncertainty_threshold_kcal)[0]
        
        selected_coords = candidate_coords[indices]
        selected_metadata = [candidate_metadata[i] for i in indices]
        selected_uncertainties = uncertainties_kcal[indices]
        
        # Tag metadata
        for m, unc in zip(selected_metadata, selected_uncertainties):
            m['selection_method'] = 'uncertainty'
            m['uncertainty_kcal'] = float(unc)
        
        print(f"    Selected {len(selected_coords)} high-uncertainty points")
        if len(selected_coords) > 0:
            print(f"    Uncertainty range: {selected_uncertainties.min():.2f} - {selected_uncertainties.max():.2f} kcal/mol")
        
        return selected_coords, selected_metadata, selected_uncertainties
    
    def compute_psi4_data(
        self,
        coords_batch: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute PSI4 energies and forces for batch.
        
        Args:
            coords_batch: Coordinates (N, n_atoms, 3)
            
        Returns:
            energies: (N,) in Hartree
            forces: (N, n_atoms, 3) in Hartree/Angstrom
        """
        import psi4
        
        print(f"\n  [PSI4 Computation]")
        print(f"    Points: {len(coords_batch)}")
        print(f"    Theory: {self.config.method}/{self.config.basis}")
        
        energies = []
        forces_list = []
        failed = 0
        
        try:
            from tqdm import tqdm
            use_tqdm = True
        except ImportError:
            use_tqdm = False
        
        iterator = tqdm(coords_batch, desc="PSI4") if use_tqdm else coords_batch
        
        for coords in iterator:
            try:
                # Create molecule string
                mol_str = "0 1\n"
                for s, c in zip(self.symbols, coords):
                    mol_str += f"{s} {c[0]:.10f} {c[1]:.10f} {c[2]:.10f}\n"
                mol_str += "units angstrom\nno_reorient\nno_com"
                
                # Clean PSI4
                psi4.core.clean_options()
                psi4.core.clean()
                psi4.core.be_quiet()
                psi4.set_memory('2 GB')
                psi4.set_num_threads(4)
                
                mol = psi4.geometry(mol_str, tooclose=0.1)
                
                psi4.set_options({
                    'basis': self.config.basis,
                    'scf_type': 'df',
                    'reference': 'rhf',
                    'maxiter': 200,
                    'e_convergence': 1e-6,
                    'd_convergence': 1e-6
                })
                
                # Compute gradient
                method_string = f"{self.config.method}/{self.config.basis}"
                energy, wfn = psi4.energy(method_string, molecule=mol, return_wfn=True)
                gradient = psi4.gradient(method_string, molecule=mol, ref_wfn=wfn)
                
                # Convert gradient to forces
                forces = -np.array(gradient)
                
                energies.append(energy)
                forces_list.append(forces)
                
            except Exception as e:
                failed += 1
                # Use ML-PES prediction as fallback
                energy, forces = self.ml_pes_model.predict_with_forces(coords)
                energies.append(energy)
                forces_list.append(forces)
        
        print(f"\n    ✓ Completed: {len(coords_batch) - failed}/{len(coords_batch)} successful")
        if failed > 0:
            print(f"    ⚠️  {failed} failed (using ML-PES fallback)")
        
        return np.array(energies), np.array(forces_list)
    
    def run_refinement_iteration(
        self,
        iteration: int,
        current_training_coords: np.ndarray,
        current_training_energies: np.ndarray,
        current_training_forces: np.ndarray
    ) -> RefinementResult:
        """
        Run one iteration of refinement.
        
        Args:
            iteration: Iteration number
            current_training_coords: Current training coordinates
            current_training_energies: Current training energies
            current_training_forces: Current training forces
            
        Returns:
            RefinementResult object
        """
        print(f"\n{'='*70}")
        print(f"Refinement Iteration {iteration}/{self.config.max_iterations}")
        print(f"{'='*70}")
        
        all_candidates = []
        all_metadata = []
        
        # 1. Normal mode sampling
        if self.config.use_normal_modes:
            nm_coords, nm_meta = self.generate_candidate_points_normal_modes()
            all_candidates.append(nm_coords)
            all_metadata.extend(nm_meta)
        
        # 2. MD exploration
        md_coords, md_meta = self.generate_candidate_points_md_exploration(
            n_candidates=500,
            temperature=300.0,
            n_steps=1000
        )
        all_candidates.append(md_coords)
        all_metadata.extend(md_meta)
        
        # Combine all candidates
        if len(all_candidates) > 0:
            combined_coords = np.vstack(all_candidates)
        else:
            combined_coords = md_coords
        
        print(f"\n  Total candidates: {len(combined_coords)}")
        
        # 3. Select by uncertainty
        if self.config.use_uncertainty and self.gp_model is not None:
            selected_coords, selected_meta, _ = self.select_points_by_uncertainty(
                combined_coords,
                all_metadata
            )
        else:
            # Random selection
            n_select = min(self.config.batch_size, len(combined_coords))
            indices = np.random.choice(len(combined_coords), n_select, replace=False)
            selected_coords = combined_coords[indices]
            selected_meta = [all_metadata[i] for i in indices]
        
        # Limit to batch size
        if len(selected_coords) > self.config.batch_size:
            selected_coords = selected_coords[:self.config.batch_size]
            selected_meta = selected_meta[:self.config.batch_size]
        
        print(f"\n  Selected for refinement: {len(selected_coords)} points")
        
        # 4. Compute PSI4 data
        new_energies, new_forces = self.compute_psi4_data(selected_coords)
        
        # 5. Count sources
        source_counts = {}
        for meta in selected_meta:
            source = meta.get('source', 'unknown')
            source_counts[source] = source_counts.get(source, 0) + 1
        
        print(f"\n  Source breakdown:")
        for source, count in source_counts.items():
            print(f"    {source}: {count}")
        
        # Create result
        result = RefinementResult(
            iteration=iteration,
            n_points_added=len(selected_coords),
            source_breakdown=source_counts,
            coordinates_added=selected_coords,
            energies_added=new_energies,
            forces_added=new_forces,
            model_rmse_before=0.0,  # Will be filled by retraining
            model_rmse_after=0.0,
            improvement_pct=0.0
        )
        
        # Save iteration results
        iter_file = self.config.output_dir / f'iteration_{iteration}_points.npz'
        np.savez(
            iter_file,
            coordinates=selected_coords,
            energies=new_energies,
            forces=new_forces,
            symbols=self.symbols,
            metadata=selected_meta
        )
        print(f"\n  ✓ Saved: {iter_file}")
        
        return result
    
    def save_refinement_history(self):
        """Save complete refinement history."""
        history_file = self.config.output_dir / 'refinement_history.json'
        
        # Convert to JSON-serializable format
        history_data = {
            'config': {
                'use_normal_modes': self.config.use_normal_modes,
                'use_uncertainty': self.config.use_uncertainty,
                'use_error_based': self.config.use_error_based,
                'batch_size': self.config.batch_size,
                'max_iterations': self.config.max_iterations,
                'method': self.config.method,
                'basis': self.config.basis
            },
            'iterations': [
                {
                    'iteration': r.iteration,
                    'n_points_added': r.n_points_added,
                    'source_breakdown': r.source_breakdown,
                    'model_rmse_before': float(r.model_rmse_before),
                    'model_rmse_after': float(r.model_rmse_after),
                    'improvement_pct': float(r.improvement_pct)
                }
                for r in self.refinement_history
            ]
        }
        
        with open(history_file, 'w') as f:
            json.dump(history_data, f, indent=2)
        
        print(f"\n✓ Refinement history saved: {history_file}")


if __name__ == "__main__":
    print("Active Learning Coordinator Module")
    print("=" * 60)
    print("\nThis module provides:")
    print("  • ActiveLearningCoordinator - Orchestrate refinement")
    print("  • RefinementConfig - Configuration dataclass")
    print("  • RefinementResult - Results dataclass")
    print("\nUsage:")
    print("  from active_learning import ActiveLearningCoordinator, RefinementConfig")
    print("\nSee documentation for examples.")
