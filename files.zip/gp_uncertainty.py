#!/usr/bin/env python3
"""
Gaussian Process Uncertainty Quantification for ML-PES
======================================================
Predict uncertainty in ML-PES predictions using Gaussian Process regression.

This module provides uncertainty estimates to guide active learning and
identify regions where the ML-PES needs refinement.

Author: Jonathan
Date: 2026-01-20
Version: 1.0
"""

import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Callable
from dataclasses import dataclass
import pickle


@dataclass
class UncertaintyPrediction:
    """Container for uncertainty predictions."""
    mean_energy: float  # Predicted energy (Hartree)
    std_energy: float  # Uncertainty in energy (Hartree)
    mean_forces: Optional[np.ndarray] = None  # Predicted forces
    std_forces: Optional[np.ndarray] = None  # Uncertainty in forces
    
    def energy_uncertainty_kcal(self) -> float:
        """Return energy uncertainty in kcal/mol."""
        return self.std_energy * 627.509
    
    def is_high_uncertainty(self, threshold_kcal: float = 5.0) -> bool:
        """Check if uncertainty exceeds threshold."""
        return self.energy_uncertainty_kcal() > threshold_kcal


class GaussianProcessPES:
    """
    Gaussian Process model for potential energy surface with uncertainty.
    
    This uses GP regression to provide both predictions and uncertainty
    estimates, enabling active learning strategies.
    """
    
    def __init__(
        self,
        kernel: str = 'rbf',
        length_scale: float = 1.0,
        alpha: float = 1e-5,
        normalize_y: bool = True
    ):
        """
        Initialize GP-PES model.
        
        Args:
            kernel: Kernel type ('rbf', 'matern')
            length_scale: Initial length scale for kernel
            alpha: Regularization parameter (noise variance)
            normalize_y: Whether to normalize target values
        """
        from sklearn.gaussian_process import GaussianProcessRegressor
        from sklearn.gaussian_process.kernels import RBF, Matern, ConstantKernel as C
        
        self.kernel_type = kernel
        self.length_scale = length_scale
        self.alpha = alpha
        self.normalize_y = normalize_y
        
        # Create kernel
        if kernel == 'rbf':
            kernel_obj = C(1.0, (1e-3, 1e3)) * RBF(
                length_scale=length_scale,
                length_scale_bounds=(1e-2, 1e2)
            )
        elif kernel == 'matern':
            kernel_obj = C(1.0, (1e-3, 1e3)) * Matern(
                length_scale=length_scale,
                length_scale_bounds=(1e-2, 1e2),
                nu=2.5
            )
        else:
            raise ValueError(f"Unknown kernel: {kernel}")
        
        # Create GP model
        self.gp = GaussianProcessRegressor(
            kernel=kernel_obj,
            alpha=alpha,
            normalize_y=normalize_y,
            n_restarts_optimizer=5,
            random_state=42
        )
        
        self.is_trained = False
        self.scaler_X = None
        self.scaler_y = None
        self.symbols = None
        self.descriptor_func = None
    
    def set_descriptor_function(
        self,
        symbols: List[str],
        descriptor_func: Callable
    ):
        """
        Set the descriptor function for converting coordinates to features.
        
        Args:
            symbols: Atomic symbols
            descriptor_func: Function that takes (symbols, coords) and returns descriptor
        """
        self.symbols = symbols
        self.descriptor_func = descriptor_func
    
    def compute_descriptor(self, coords: np.ndarray) -> np.ndarray:
        """Compute molecular descriptor for coordinates."""
        if self.descriptor_func is None:
            raise RuntimeError("Descriptor function not set. Call set_descriptor_function().")
        
        return self.descriptor_func(self.symbols, coords)
    
    def fit(
        self,
        coordinates: np.ndarray,
        energies: np.ndarray,
        descriptor_func: Optional[Callable] = None,
        symbols: Optional[List[str]] = None
    ):
        """
        Fit GP model to training data.
        
        Args:
            coordinates: Training coordinates (N, n_atoms, 3)
            energies: Training energies (N,) in Hartree
            descriptor_func: Optional descriptor function
            symbols: Optional atomic symbols
        """
        from sklearn.preprocessing import StandardScaler
        
        print(f"\n{'='*60}")
        print(f"Training Gaussian Process PES")
        print(f"{'='*60}")
        print(f"  Training points: {len(coordinates)}")
        print(f"  Kernel: {self.kernel_type}")
        print(f"  Alpha: {self.alpha}")
        
        # Set descriptor if provided
        if descriptor_func is not None and symbols is not None:
            self.set_descriptor_function(symbols, descriptor_func)
        
        # Compute descriptors
        print(f"\n  Computing descriptors...")
        X = np.array([self.compute_descriptor(coords) for coords in coordinates])
        y = energies.copy()
        
        print(f"  Descriptor shape: {X.shape}")
        
        # Scale features
        self.scaler_X = StandardScaler()
        X_scaled = self.scaler_X.fit_transform(X)
        
        # Scale targets
        self.scaler_y = StandardScaler()
        y_scaled = self.scaler_y.fit_transform(y.reshape(-1, 1)).ravel()
        
        # Fit GP
        print(f"\n  Fitting Gaussian Process...")
        print(f"  (This may take a few minutes for large datasets)")
        
        self.gp.fit(X_scaled, y_scaled)
        
        self.is_trained = True
        
        # Report optimized parameters
        print(f"\n✓ GP model trained")
        print(f"  Log-marginal likelihood: {self.gp.log_marginal_likelihood_value_:.2f}")
        print(f"  Optimized kernel: {self.gp.kernel_}")
    
    def predict_with_uncertainty(
        self,
        coords: np.ndarray,
        return_std: bool = True
    ) -> UncertaintyPrediction:
        """
        Predict energy and uncertainty for geometry.
        
        Args:
            coords: Coordinates (n_atoms, 3)
            return_std: Whether to compute standard deviation
            
        Returns:
            UncertaintyPrediction object
        """
        if not self.is_trained:
            raise RuntimeError("Model not trained. Call fit() first.")
        
        # Compute descriptor
        desc = self.compute_descriptor(coords)
        desc_scaled = self.scaler_X.transform(desc.reshape(1, -1))
        
        # Predict
        if return_std:
            y_pred, y_std = self.gp.predict(desc_scaled, return_std=True)
            
            # Unscale predictions
            energy_pred = self.scaler_y.inverse_transform(y_pred.reshape(-1, 1))[0, 0]
            
            # Unscale uncertainty (std scales linearly with target scale)
            energy_std = y_std[0] * self.scaler_y.scale_[0]
        else:
            y_pred = self.gp.predict(desc_scaled)
            energy_pred = self.scaler_y.inverse_transform(y_pred.reshape(-1, 1))[0, 0]
            energy_std = 0.0
        
        return UncertaintyPrediction(
            mean_energy=energy_pred,
            std_energy=energy_std
        )
    
    def predict_batch_with_uncertainty(
        self,
        coordinates: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Predict energies and uncertainties for batch of geometries.
        
        Args:
            coordinates: Batch of coordinates (N, n_atoms, 3)
            
        Returns:
            energies: Predicted energies (N,)
            uncertainties: Energy uncertainties (N,)
        """
        if not self.is_trained:
            raise RuntimeError("Model not trained. Call fit() first.")
        
        # Compute descriptors
        X = np.array([self.compute_descriptor(coords) for coords in coordinates])
        X_scaled = self.scaler_X.transform(X)
        
        # Predict
        y_pred, y_std = self.gp.predict(X_scaled, return_std=True)
        
        # Unscale
        energies = self.scaler_y.inverse_transform(y_pred.reshape(-1, 1)).ravel()
        uncertainties = y_std * self.scaler_y.scale_[0]
        
        return energies, uncertainties
    
    def identify_high_uncertainty_points(
        self,
        coordinates: np.ndarray,
        threshold_kcal: float = 5.0,
        top_n: Optional[int] = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Identify high-uncertainty points for active learning.
        
        Args:
            coordinates: Candidate coordinates (N, n_atoms, 3)
            threshold_kcal: Uncertainty threshold (kcal/mol)
            top_n: Return top N most uncertain (None = all above threshold)
            
        Returns:
            high_unc_coords: High uncertainty coordinates
            high_unc_indices: Indices of high uncertainty points
            uncertainties: All uncertainties (kcal/mol)
        """
        print(f"\n{'='*60}")
        print(f"Identifying High Uncertainty Points")
        print(f"{'='*60}")
        print(f"  Candidates: {len(coordinates)}")
        print(f"  Threshold: {threshold_kcal} kcal/mol")
        
        # Predict uncertainties
        _, uncertainties = self.predict_batch_with_uncertainty(coordinates)
        uncertainties_kcal = uncertainties * 627.509
        
        # Find high uncertainty points
        if top_n is not None:
            # Select top N most uncertain
            indices = np.argsort(uncertainties_kcal)[::-1][:top_n]
        else:
            # Select all above threshold
            indices = np.where(uncertainties_kcal > threshold_kcal)[0]
        
        print(f"\n✓ High uncertainty points: {len(indices)}")
        
        if len(indices) > 0:
            print(f"  Uncertainty range: {uncertainties_kcal[indices].min():.2f} - {uncertainties_kcal[indices].max():.2f} kcal/mol")
            print(f"  Mean uncertainty: {uncertainties_kcal[indices].mean():.2f} kcal/mol")
        
        return coordinates[indices], indices, uncertainties_kcal
    
    def acquisition_function(
        self,
        coords: np.ndarray,
        acquisition_type: str = 'uncertainty'
    ) -> float:
        """
        Compute acquisition function value for active learning.
        
        Args:
            coords: Coordinates (n_atoms, 3)
            acquisition_type: 'uncertainty', 'ucb' (upper confidence bound)
            
        Returns:
            Acquisition value (higher = more valuable to sample)
        """
        pred = self.predict_with_uncertainty(coords)
        
        if acquisition_type == 'uncertainty':
            # Pure uncertainty sampling
            return pred.std_energy
        
        elif acquisition_type == 'ucb':
            # Upper confidence bound (exploration-exploitation tradeoff)
            # UCB = μ + κ·σ where κ controls exploration
            kappa = 2.0  # Exploration parameter
            return pred.mean_energy + kappa * pred.std_energy
        
        else:
            raise ValueError(f"Unknown acquisition type: {acquisition_type}")
    
    def save(self, filepath: Path):
        """Save trained GP model."""
        if not self.is_trained:
            raise RuntimeError("Cannot save untrained model")
        
        model_data = {
            'gp': self.gp,
            'scaler_X': self.scaler_X,
            'scaler_y': self.scaler_y,
            'symbols': self.symbols,
            'kernel_type': self.kernel_type,
            'is_trained': self.is_trained,
            'metadata': {
                'alpha': self.alpha,
                'normalize_y': self.normalize_y
            }
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"\n✓ GP model saved: {filepath}")
    
    @classmethod
    def load(cls, filepath: Path, descriptor_func: Callable, symbols: List[str]):
        """Load trained GP model."""
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        # Create instance
        model = cls(
            kernel=model_data['kernel_type'],
            alpha=model_data['metadata']['alpha'],
            normalize_y=model_data['metadata']['normalize_y']
        )
        
        # Restore state
        model.gp = model_data['gp']
        model.scaler_X = model_data['scaler_X']
        model.scaler_y = model_data['scaler_y']
        model.symbols = model_data['symbols']
        model.is_trained = model_data['is_trained']
        model.descriptor_func = descriptor_func
        
        print(f"✓ GP model loaded: {filepath}")
        
        return model


class UncertaintyTracker:
    """
    Track uncertainty predictions during ML-PES usage.
    
    This helps monitor when the ML-PES is being used in regions
    where it may be unreliable.
    """
    
    def __init__(self, warning_threshold_kcal: float = 5.0):
        """
        Initialize uncertainty tracker.
        
        Args:
            warning_threshold_kcal: Issue warning above this uncertainty
        """
        self.warning_threshold = warning_threshold_kcal
        self.predictions = []
        self.warnings_issued = 0
    
    def record_prediction(self, prediction: UncertaintyPrediction):
        """Record an uncertainty prediction."""
        self.predictions.append(prediction)
        
        if prediction.is_high_uncertainty(self.warning_threshold):
            self.warnings_issued += 1
    
    def get_statistics(self) -> Dict:
        """Get uncertainty statistics."""
        if len(self.predictions) == 0:
            return {'n_predictions': 0}
        
        uncertainties = np.array([p.energy_uncertainty_kcal() for p in self.predictions])
        
        return {
            'n_predictions': len(self.predictions),
            'mean_uncertainty_kcal': float(uncertainties.mean()),
            'std_uncertainty_kcal': float(uncertainties.std()),
            'max_uncertainty_kcal': float(uncertainties.max()),
            'n_warnings': self.warnings_issued,
            'warning_fraction': self.warnings_issued / len(self.predictions)
        }
    
    def should_refine(self, fraction_threshold: float = 0.1) -> bool:
        """
        Determine if model should be refined based on uncertainty.
        
        Args:
            fraction_threshold: Refine if this fraction of predictions are uncertain
            
        Returns:
            True if refinement recommended
        """
        stats = self.get_statistics()
        
        if stats['n_predictions'] < 10:
            return False  # Need more data
        
        return stats['warning_fraction'] > fraction_threshold


if __name__ == "__main__":
    print("Gaussian Process Uncertainty Quantification Module")
    print("=" * 60)
    print("\nThis module provides:")
    print("  • GaussianProcessPES - GP model with uncertainty")
    print("  • UncertaintyPrediction - Results container")
    print("  • UncertaintyTracker - Monitor predictions")
    print("  • Active learning tools")
    print("\nUsage:")
    print("  from gp_uncertainty import GaussianProcessPES")
    print("\nSee documentation for examples.")
